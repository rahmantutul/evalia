

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">System Settings</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Update System Settings</h4>
                    <hr>
                    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Company Information -->
                        <div class="mb-4">
                            <h5>Company Information</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Company Name</label>
                                        <input type="text" class="form-control" name="company_name" 
                                               value="<?php echo e(old('company_name', $settings->company_name)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Company Tagline</label>
                                        <input type="text" class="form-control" name="company_tagline" 
                                               value="<?php echo e(old('company_tagline', $settings->company_tagline)); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Company Logo</label>
                                        <input type="file" class="form-control" name="company_logo" id="company_logo" onchange="previewImage(this, 'logo-preview')">
                                        
                                        <?php if($settings->company_logo): ?>
                                        <div class="mt-2">
                                            <h6>Current Logo:</h6>
                                            <img src="<?php echo e(asset('storage/' . $settings->company_logo)); ?>" 
                                                 id="logo-preview" 
                                                 class="img-thumbnail" 
                                                 style="max-height: 100px; max-width: 200px;">
                                        </div>
                                        <?php else: ?>
                                        <div class="mt-2">
                                            <img src="https://via.placeholder.com/200x100?text=No+Logo" 
                                                 id="logo-preview" 
                                                 class="img-thumbnail" 
                                                 style="max-height: 100px; max-width: 200px;">
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Favicon</label>
                                        <input type="file" class="form-control" name="favicon" id="favicon" onchange="previewImage(this, 'favicon-preview')">
                                        
                                        <?php if($settings->favicon): ?>
                                        <div class="mt-2">
                                            <h6>Current Favicon:</h6>
                                            <img src="<?php echo e(asset('storage/' . $settings->favicon)); ?>" 
                                                 id="favicon-preview" 
                                                 class="img-thumbnail" 
                                                 style="max-height: 50px; max-width: 50px;">
                                        </div>
                                        <?php else: ?>
                                        <div class="mt-2">
                                            <img src="https://via.placeholder.com/50x50?text=No+Favicon" 
                                                 id="favicon-preview" 
                                                 class="img-thumbnail" 
                                                 style="max-height: 50px; max-width: 50px;">
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Pricing Title</label>
                                        <input type="text" class="form-control" name="pricing_title" 
                                            value="<?php echo e(old('pricing_title', $settings->pricing_title)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                     <div class="mb-3">
                                        <label class="form-label">Pricing Subtitle</label>
                                        <input type="text" class="form-control" name="pricing_subtitle" 
                                            value="<?php echo e(old('pricing_subtitle', $settings->pricing_subtitle)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Offer Text</label>
                                        <input type="text" class="form-control" name="offer_text" value="<?php echo e(old('offer_text', $settings->offer_text)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Welcome Text</label>
                                        <input type="text" class="form-control" name="dashboard_text" 
                                            value="<?php echo e(old('dashboard_text', $settings->dashboard_text)); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                     <div class="mb-3">
                                        <label class="form-label">Subtext</label>
                                        <input type="text" class="form-control" name="dashboard_subtext" 
                                            value="<?php echo e(old('dashboard_subtext', $settings->dashboard_subtext)); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Save Settings</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    function previewImage(input, previewId) {
        const preview = document.getElementById(previewId);
        const file = input.files[0];
        
        if (file) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                preview.src = e.target.result;
            }
            
            reader.readAsDataURL(file);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\voice-bot-dashboard\resources\views/admin/system_setting.blade.php ENDPATH**/ ?>