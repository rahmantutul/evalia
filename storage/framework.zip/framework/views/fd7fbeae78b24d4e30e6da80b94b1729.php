    <div class="startbar d-print-none">
        <div class="brand d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('agent.dashboard')); ?>" class="logo text-center">
                <span>
                    <img src="<?php echo e(asset('/')); ?>assets/images/preview.png" alt="logo-small" class="logo-sm mx-auto">
                </span>
                <span>
                    <img src="<?php echo e(asset('/')); ?>assets/images/logo.png" height="100" alt="logo-large" class="logo-lg logo-light mx-auto">
                    <img src="<?php echo e(asset('/')); ?>assets/images/logo.png" height="100" alt="logo-large" class="logo-lg logo-dark mx-auto">
                </span>
            </a>
        </div>

        <div class="startbar-menu">
            <div class="startbar-collapse" id="startbarCollapse" data-simplebar>
                <div class="d-flex align-items-start flex-column w-100">
                    <!-- Navigation -->
                    <ul class="navbar-nav mb-auto w-100">
                        <li class="nav-item <?php echo e(Route::is('agent.dashboard') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('agent.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('agent.dashboard')); ?>">
                                <i class="iconoir-report-columns menu-icon"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Route::is('agent.coaching') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('agent.coaching') ? 'active' : ''); ?>" href="<?php echo e(route('agent.coaching')); ?>">
                                <i class="fas fa-graduation-cap menu-icon"></i>
                                <span>Coaching & Growth</span>
                            </a>
                        </li>
                    </ul><!--end navbar-nav--->
                    
                </div>
            </div><!--end startbar-collapse-->
        </div>   
    </div><?php /**PATH C:\xampp\htdocs\evalia\resources\views/agent/layouts/sidebar.blade.php ENDPATH**/ ?>