<div class="startbar d-print-none">
    <div class="brand d-flex justify-content-center align-items-center">
        <a href="<?php echo e(route('user.home')); ?>" class="logo text-center">
            <span>
                <img src="<?php echo e(asset('/')); ?>assets/images/preview.png" alt="logo-small" class="logo-sm mx-auto">
            </span>
            <span>
                <img src="<?php echo e(asset('/')); ?>assets/images/logo.png" height="100" alt="logo-large" class="logo-lg logo-light mx-auto">
                <img src="<?php echo e(asset('/')); ?>assets/images/logo.png" height="100" alt="logo-large" class="logo-lg logo-dark mx-auto">
            </span>
        </a>
    </div>

    <div class="startbar-menu">
        <div class="startbar-collapse" id="startbarCollapse" data-simplebar>
            <div class="d-flex align-items-start flex-column w-100">
                <!-- Navigation -->
                <ul class="navbar-nav mb-auto w-100">

                    
                    <?php if(auth()->user()->isAgent()): ?>
                        <li class="nav-item <?php echo e(Route::is('agent.dashboard') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('agent.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('agent.dashboard')); ?>">
                                <i class="iconoir-report-columns menu-icon"></i>
                                <span>Agent Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(Route::is('agent.coaching') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('agent.coaching') ? 'active' : ''); ?>" href="<?php echo e(route('agent.coaching')); ?>">
                                <i class="fas fa-graduation-cap menu-icon"></i>
                                <span>My Coaching</span>
                            </a>
                        </li>

                    
                    <?php else: ?>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.view')): ?>
                        <li class="nav-item <?php echo e(Route::is('user.home') || Route::is('supervisor.dashboard') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('user.home') ? 'active' : ''); ?>" href="<?php echo e(route('user.home')); ?>">
                                <i class="iconoir-report-columns menu-icon"></i>
                                <span><?php echo e(auth()->user()->isSupervisor() ? 'Supervisor Dashboard' : 'Dashboard'); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>
                        <li class="nav-item <?php echo e(Route::is('roles.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('roles.*') ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">
                                <i class="fas fa-lock menu-icon"></i>
                                <span>Roles &amp; Permissions</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.view')): ?>
                        <li class="nav-item <?php echo e(Route::is('users.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('users.*') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">
                                <i class="fas fa-user-check menu-icon"></i>
                                <span>Users</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('companies.view')): ?>
                        <li class="nav-item <?php echo e(Route::is('user.company.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('user.company.*') ? 'active' : ''); ?>" href="<?php echo e(route('user.company.list')); ?>">
                                <i class="icofont-bank-alt menu-icon"></i>
                                <span>Companies</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('knowledgebase.view')): ?>
                        <li class="nav-item <?php echo e(Route::is('user.knowledgeBase.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('user.knowledgeBase.*') ? 'active' : ''); ?>" href="<?php echo e(route('user.knowledgeBase.list')); ?>">
                                <i class="fas fa-brain menu-icon"></i>
                                <span>Knowledgebase</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <li class="nav-item <?php echo e(Route::is('user.extractions.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('user.extractions.agent-wise') ? 'active' : ''); ?>" href="<?php echo e(route('user.extractions.agent-wise')); ?>">
                                <i class="fas fa-file-invoice menu-icon"></i>
                                <span>Extracted Intelligence</span>
                            </a>
                        </li>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agents.view')): ?>
                        <li class="nav-item <?php echo e(Route::is('user.agents.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('user.agents.index.*') ? 'active' : ''); ?>" href="<?php echo e(route('user.agents.index')); ?>">
                                <i class="fas fa-headset menu-icon"></i>
                                <span>Agents</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('evaluationroles.view')): ?>
                        <li class="nav-item <?php echo e(Route::is('user.evaluation_roles.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('user.evaluation_roles.*') ? 'active' : ''); ?>" href="<?php echo e(route('user.evaluation_roles.index')); ?>">
                                <i class="fas fa-user-shield menu-icon"></i>
                                <span>Evaluation Roles</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <li class="nav-item <?php echo e(Route::is('user.voice-pint.*') ? 'active' : ''); ?>">
                            <a class="nav-link <?php echo e(Route::is('user.voice-pint.*') ? 'active' : ''); ?>" href="<?php echo e(route('user.voice-pint.index')); ?>">
                                <i class="fas fa-microphone-alt menu-icon"></i>
                                <span>Voice Print</span>
                            </a>
                        </li>

                    <?php endif; ?>

                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(asset('documentation.html')); ?>" target="_blank">
                            <i class="fas fa-book menu-icon"></i>
                            <span>Documentation</span>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\evalia\resources\views/user/layouts/sidebar.blade.php ENDPATH**/ ?>