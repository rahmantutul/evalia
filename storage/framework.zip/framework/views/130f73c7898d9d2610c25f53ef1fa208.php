

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-header bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title mb-0">
                                <i class="fas fa-info-circle me-2"></i>Job Details
                            </h5>
                            <small class="text-muted">Type: <?php echo e($job['type'] ?? 'UNKNOWN'); ?></small>
                        </div>
                        <a href="<?php echo e(url('/hamsa/jobs')); ?>" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-arrow-left me-1"></i> Back to Jobs
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(isset($job) && !isset($error)): ?>
                        <?php
                            $jobType = $job['type'] ?? 'UNKNOWN';
                            $jobResponse = $job['jobResponse'] ?? [];
                        ?>

                        <!-- Basic Info Card -->
                        <div class="card mb-4">
                            <div class="card-header bg-light py-2">
                                <h6 class="mb-0">Basic Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <table class="table table-sm table-borderless">
                                            <tr>
                                                <td class="text-muted" width="30%">Title:</td>
                                                <td><strong><?php echo e($job['title'] ?? 'N/A'); ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Type:</td>
                                                <td>
                                                    <span class="badge bg-light text-dark">
                                                        <?php echo e($jobType); ?>

                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Status:</td>
                                                <td>
                                                    <span class="badge 
                                                        <?php if($job['status'] == 'COMPLETED'): ?> bg-success
                                                        <?php elseif($job['status'] == 'FAILED'): ?> bg-danger
                                                        <?php elseif($job['status'] == 'PROCESSING'): ?> bg-info
                                                        <?php else: ?> bg-warning <?php endif; ?>">
                                                        <?php echo e($job['status'] ?? 'N/A'); ?>

                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Job ID:</td>
                                                <td><code class="small"><?php echo e($job['id'] ?? 'N/A'); ?></code></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-md-6">
                                        <table class="table table-sm table-borderless">
                                            <tr>
                                                <td class="text-muted" width="30%">Cost:</td>
                                                <td><strong><?php echo e($job['cost'] ?? $job['totalCost'] ?? 0); ?> credits</strong></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Created:</td>
                                                <td><?php echo e(isset($job['createdAt']) ? \Carbon\Carbon::parse($job['createdAt'])->format('M j, Y H:i') : 'N/A'); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-muted">Updated:</td>
                                                <td><?php echo e(isset($job['updatedAt']) ? \Carbon\Carbon::parse($job['updatedAt'])->format('M j, Y H:i') : 'N/A'); ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- VOICE_AGENTS Specific Content -->
                        <?php if($jobType === 'VOICE_AGENTS'): ?>
                            <!-- Call Information -->
                            <div class="card mb-4">
                                <div class="card-header bg-light py-2">
                                    <h6 class="mb-0">Call Information</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <strong>Duration:</strong> <?php echo e($job['callDuration'] ?? 0); ?> seconds<br>
                                            <strong>Started:</strong> 
                                            <?php echo e(isset($jobResponse['callStartedAt']) ? \Carbon\Carbon::parse($jobResponse['callStartedAt'])->format('M j, Y H:i:s') : 'N/A'); ?><br>
                                            <strong>Ended:</strong> 
                                            <?php echo e(isset($jobResponse['callEndedAt']) ? \Carbon\Carbon::parse($jobResponse['callEndedAt'])->format('M j, Y H:i:s') : 'N/A'); ?>

                                        </div>
                                        <div class="col-md-8">
                                            <?php if(isset($job['agentDetails'])): ?>
                                                <strong>Agent:</strong> <?php echo e($job['agentDetails']['agentName'] ?? 'N/A'); ?><br>
                                                <strong>Language:</strong> <?php echo e($job['agentDetails']['lang'] ?? 'N/A'); ?><br>
                                                <strong>Voice:</strong> <?php echo e($job['agentDetails']['ttsVoice']['name'] ?? 'N/A'); ?><br>
                                                <strong>Greeting:</strong> <?php echo e($job['agentDetails']['greetingMessage'] ?? 'N/A'); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Conversation Transcript -->
                            <?php if(isset($jobResponse['transcription']) && !empty($jobResponse['transcription'])): ?>
                            <div class="card mb-4">
                                <div class="card-header bg-light py-2 d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0">Conversation Transcript</h6>
                                    <span class="badge bg-primary"><?php echo e(count($jobResponse['transcription'])); ?> messages</span>
                                </div>
                                <div class="card-body p-0">
                                    <div class="conversation-container" style="max-height: 500px; overflow-y: auto;">
                                        <?php $__currentLoopData = $jobResponse['transcription']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speaker => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    // Determine if this is the agent or user
                                                    $isAgent = $speaker === ($job['agentDetails']['agentName'] ?? 'Agent');
                                                    $speakerType = $isAgent ? 'Agent' : 'User';
                                                    $speakerDisplayName = $isAgent ? ($job['agentDetails']['agentName'] ?? 'Agent') : 'User';
                                                ?>
                                                <div class="message-row p-3 <?php echo e($isAgent ? 'bg-light' : ''); ?> border-bottom">
                                                    <div class="d-flex align-items-start">
                                                        <div class="message-avatar me-3">
                                                            <?php if($isAgent): ?>
                                                                <span class="badge bg-success rounded-circle p-2">
                                                                    <i class="fas fa-robot"></i>
                                                                </span>
                                                            <?php else: ?>
                                                                <span class="badge bg-primary rounded-circle p-2">
                                                                    <i class="fas fa-user"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="message-content flex-grow-1">
                                                            <div class="d-flex justify-content-between align-items-start mb-1">
                                                                <strong class="text-<?php echo e($isAgent ? 'success' : 'primary'); ?>">
                                                                    <?php echo e($speakerDisplayName); ?>

                                                                </strong>
                                                                <small class="text-muted">#<?php echo e($index + 1); ?></small>
                                                            </div>
                                                            <p class="mb-0"><?php echo e($text); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Voice Configuration -->
                            <?php if(isset($job['agentDetails']['ttsVoice'])): ?>
                            <div class="card mb-4">
                                <div class="card-header bg-light py-2">
                                    <h6 class="mb-0">Voice Configuration</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <strong>Voice Name:</strong> <?php echo e($job['agentDetails']['ttsVoice']['name'] ?? 'N/A'); ?><br>
                                            <strong>Language:</strong> <?php echo e($job['agentDetails']['ttsVoice']['language'] ?? 'N/A'); ?><br>
                                            <strong>Provider:</strong> <?php echo e($job['agentDetails']['ttsVoice']['provider'] ?? 'N/A'); ?>

                                        </div>
                                        <div class="col-md-6">
                                            <strong>Tags:</strong> 
                                            <?php if(isset($job['agentDetails']['ttsVoice']['tags']) && is_array($job['agentDetails']['ttsVoice']['tags'])): ?>
                                                <?php $__currentLoopData = $job['agentDetails']['ttsVoice']['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-secondary me-1"><?php echo e($tag); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        <!-- TRANSCRIPTION Specific Content -->
                        <?php elseif($jobType === 'TRANSCRIPTION'): ?>
                            <div class="card mb-4">
                                <div class="card-header bg-light py-2">
                                    <h6 class="mb-0">Transcription Results</h6>
                                </div>
                                <div class="card-body">

                                    <strong>Audio Input:</strong>
                                    <div class="m-2">
                                        <audio controls class="w-100">
                                            <source src="<?php echo e($job['mediaUrl']); ?>" type="audio/wav">
                                            Your browser does not support the audio element.
                                        </audio>
                                    </div>
                                    <?php if(isset($jobResponse['detected_language'])): ?>
                                        <div class="mb-3">
                                            <strong>Detected Language:</strong> 
                                            <span class="badge bg-info"><?php echo e(strtoupper($jobResponse['detected_language'])); ?></span>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Full Transcription Text -->
                                    <?php if(isset($jobResponse['transcription'])): ?>
                                    <div class="mb-4">
                                        <strong>Full Transcription:</strong>
                                        <div class="mt-2 p-3 bg-light rounded" style="max-height: 300px; overflow-y: auto;">
                                            <?php echo e($jobResponse['transcription']); ?>

                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <!-- Speaker Diarization -->
                                    <?php if(isset($jobResponse['diarization']) && !empty($jobResponse['diarization'])): ?>
                                    <div>
                                        <strong>Speaker Segments:</strong>
                                        <div class="mt-2" style="max-height: 400px; overflow-y: auto;">
                                            <?php $__currentLoopData = $jobResponse['diarization']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="border-bottom pb-2 mb-2">
                                                <div class="d-flex justify-content-between align-items-start">
                                                    <span class="badge bg-secondary"><?php echo e($segment['speaker'] ?? 'Unknown'); ?></span>
                                                    <small class="text-muted">
                                                        <?php echo e(number_format($segment['start'] ?? 0, 2)); ?>s - <?php echo e(number_format($segment['end'] ?? 0, 2)); ?>s
                                                    </small>
                                                </div>
                                                <p class="mb-0 mt-1"><?php echo e($segment['text'] ?? ''); ?></p>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <!-- TTS Specific Content -->
                        <?php elseif($jobType === 'TTS'): ?>
                            <div class="card mb-4">
                                <div class="card-header bg-light py-2">
                                    <h6 class="mb-0">Text-to-Speech Results</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <?php if(isset($job['voiceName'])): ?>
                                                <strong>Voice:</strong> <?php echo e($job['voiceName']); ?><br>
                                            <?php endif; ?>
                                            <?php if(isset($job['usageTime'])): ?>
                                                <strong>Usage Time:</strong> <?php echo e($job['usageTime']); ?> seconds<br>
                                            <?php endif; ?>
                                            <?php if(isset($job['systemModelKey'])): ?>
                                                <strong>Model:</strong> <?php echo e($job['systemModelKey']); ?><br>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6">
                                            <!-- Audio Player -->
                                            <?php if(isset($jobResponse['ttsMediaFile']) || isset($job['mediaUrl'])): ?>
                                                <strong>Audio Output:</strong>
                                                <div class="mt-2">
                                                    <audio controls class="w-100">
                                                        <source src="<?php echo e($job['mediaUrl']); ?>" type="audio/wav">
                                                        Your browser does not support the audio element.
                                                    </audio>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Input Text -->
                                    <?php if(isset($jobResponse['text'])): ?>
                                    <div class="mt-4">
                                        <strong>Input Text:</strong>
                                        <div class="mt-2 p-3 bg-light rounded" style="max-height: 200px; overflow-y: auto;">
                                            <?php echo e($jobResponse['text']); ?>

                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <!-- AI_CONTENT Specific Content -->
                        <?php elseif($jobType === 'AI_CONTENT'): ?>
                            <div class="card mb-4">
                                <div class="card-header bg-light py-2">
                                    <h6 class="mb-0">AI Content Analysis</h6>
                                </div>
                                <div class="card-body">
                                    <?php if(isset($jobResponse['detected_language'])): ?>
                                        <div class="mb-3">
                                            <strong>Detected Language:</strong> 
                                            <span class="badge bg-info"><?php echo e(strtoupper($jobResponse['detected_language'])); ?></span>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Summary -->
                                    <?php if(isset($jobResponse['summary'])): ?>
                                    <div class="mb-4">
                                        <strong>Summary:</strong>
                                        <div class="mt-2 p-3 bg-light rounded">
                                            <?php echo e($jobResponse['summary']); ?>

                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <!-- Introduction -->
                                    <?php if(isset($jobResponse['introduction'])): ?>
                                    <div class="mb-4">
                                        <strong>Introduction:</strong>
                                        <div class="mt-2 p-3 bg-light rounded">
                                            <?php echo e($jobResponse['introduction']); ?>

                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <!-- Related Job -->
                                    <?php if(isset($job['relevantJobId'])): ?>
                                    <div>
                                        <strong>Related Transcription Job:</strong>
                                        <code><?php echo e($job['relevantJobId']); ?></code>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <!-- Default for Unknown Types -->
                        <?php else: ?>
                            <div class="card mb-4">
                                <div class="card-header bg-light py-2">
                                    <h6 class="mb-0">Job Data</h6>
                                </div>
                                <div class="card-body">
                                    <pre class="bg-light p-3 rounded small" style="max-height: 400px; overflow-y: auto;"><code><?php echo json_encode($job, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE, 512) ?></code></pre>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Additional Technical Details -->
                        <div class="card mb-4">
                            <div class="card-header bg-light py-2">
                                <h6 class="mb-0">Technical Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <?php if(isset($job['systemModelKey'])): ?>
                                            <strong>Model:</strong> <?php echo e($job['systemModelKey']); ?><br>
                                        <?php endif; ?>
                                        <?php if(isset($job['processingType'])): ?>
                                            <strong>Processing Type:</strong> <?php echo e($job['processingType']); ?><br>
                                        <?php endif; ?>
                                        <?php if(isset($job['usageTime'])): ?>
                                            <strong>Usage Time:</strong> <?php echo e($job['usageTime']); ?><br>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <?php if(isset($job['apiKeyId'])): ?>
                                            <strong>API Key ID:</strong> <code class="small"><?php echo e($job['apiKeyId']); ?></code><br>
                                        <?php endif; ?>
                                        <?php if(isset($job['userId'])): ?>
                                            <strong>User ID:</strong> <code class="small"><?php echo e($job['userId']); ?></code><br>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Actions Section -->
                        <div class="card">
                            <div class="card-header bg-light py-2">
                                <h6 class="mb-0">Actions</h6>
                            </div>
                            <div class="card-body">
                                <div class="d-flex gap-2 flex-wrap align-items-center">
                                    <!-- For TTS, show both player and download -->
                                    <?php if($jobType === 'TTS' && (isset($jobResponse['mediaUrl']) || isset($job['mediaUrl']))): ?>
                                        <?php
                                            $audioUrl = $jobResponse['mediaUrl'] ?? $job['mediaUrl'];
                                        ?>
                                        <div class="d-flex align-items-center bg-light p-2 rounded me-2">
                                            <span class="me-2 small text-nowrap">Listen:</span>
                                            <audio controls style="height: 35px; min-width: 200px;">
                                                <source src="<?php echo e($audioUrl); ?>" type="audio/wav">
                                                <source src="<?php echo e($audioUrl); ?>" type="audio/mpeg">
                                            </audio>
                                        </div>
                                        
                                        <a href="<?php echo e($audioUrl); ?>" 
                                        class="btn btn-success btn-sm"
                                        target="_blank"
                                        download="tts-output-<?php echo e($job['id']); ?>.wav">
                                            <i class="fas fa-download me-1"></i> Download
                                        </a>
                                        
                                    <!-- For other types -->
                                    <?php else: ?>
                                        <?php if(isset($job['url']) && $job['status'] === 'COMPLETED'): ?>
                                            <a href="<?php echo e($job['url']); ?>" 
                                            class="btn btn-success btn-sm" 
                                            target="_blank"
                                            download>
                                                <i class="fas fa-download me-1"></i> Download Result
                                            </a>
                                        <?php endif; ?>
                                        
                                        <?php if(isset($job['mediaUrl']) && $job['status'] === 'COMPLETED'): ?>
                                            <a href="<?php echo e($job['mediaUrl']); ?>" 
                                            class="btn btn-outline-success btn-sm" 
                                            target="_blank"
                                            download>
                                                <i class="fas fa-file-audio me-1"></i> Download Media
                                            </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    <!-- Back Button -->
                                    <a href="<?php echo e(url('/hamsa/jobs')); ?>" 
                                    class="btn btn-outline-secondary btn-sm">
                                        <i class="fas fa-arrow-left me-1"></i> Back to List
                                    </a>
                                </div>
                                
                                <!-- Audio Troubleshooting Tips -->
                                <?php if($jobType === 'TTS'): ?>
                                <div class="mt-3 p-2 bg-warning bg-opacity-10 rounded small">
                                    <strong>Audio not playing?</strong>
                                    <ul class="mb-0 mt-1">
                                        <li>Click the download button to save the file</li>
                                        <li>Try opening the downloaded file with your media player</li>
                                        <li>The audio URL might require direct download due to security restrictions</li>
                                    </ul>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php else: ?>
                        <!-- Error State -->
                        <div class="text-center py-5">
                            <i class="fas fa-exclamation-triangle fa-3x text-muted mb-3"></i>
                            <h5>Job Not Found</h5>
                            <p class="text-muted"><?php echo e($error ?? 'The requested job could not be found.'); ?></p>
                            <a href="<?php echo e(url('/hamsa/jobs')); ?>" class="btn btn-primary">
                                <i class="fas fa-arrow-left me-1"></i> Back to Jobs
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.message-row {
    transition: background-color 0.2s ease;
}
.message-row:hover {
    background-color: #f8f9fa !important;
}
.conversation-container {
    scrollbar-width: thin;
    scrollbar-color: #cbd5e0 #f7fafc;
}
.conversation-container::-webkit-scrollbar {
    width: 6px;
}
.conversation-container::-webkit-scrollbar-track {
    background: #f7fafc;
}
.conversation-container::-webkit-scrollbar-thumb {
    background-color: #cbd5e0;
    border-radius: 3px;
}
.message-avatar .badge {
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
}
audio {
    border-radius: 8px;
    background: #f8f9fa;
    min-width: 250px;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/hamsa/job-details.blade.php ENDPATH**/ ?>