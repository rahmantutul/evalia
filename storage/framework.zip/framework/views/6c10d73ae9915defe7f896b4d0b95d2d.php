    <!-- Top Bar Start -->
    <div class="topbar d-print-none">
        <div class="container-fluid">
            <nav class="topbar-custom d-flex justify-content-between" id="topbar-custom">    
                
                
                <ul class="topbar-item list-unstyled d-inline-flex align-items-center mb-0">                        
                    
                    <li>
                        <button class="nav-link mobile-menu-btn nav-icon" id="togglemenu">
                            <i class="iconoir-menu"></i>
                        </button>
                    </li> 

                    
                    <li class="mx-2 welcome-text">
                        <h5 class="mb-0 fw-semibold text-truncate">
                            Hello, <?php echo e(session('user.full_name') ?? session('user.username') ?? 'Agent'); ?>!
                        </h5>
                    </li>                   
                </ul>

                
                <ul class="topbar-item list-unstyled d-inline-flex align-items-center mb-0">
                    <li class="dropdown topbar-item">
                        <a class="nav-link dropdown-toggle arrow-none nav-icon" data-bs-toggle="dropdown" href="#" role="button"
                            aria-haspopup="false" aria-expanded="false" data-bs-offset="0,19">
                            <img src="<?php echo e(session('user.avatar') ?: asset('assets/images/default-avatar.jpg')); ?>" alt="" class="thumb-md rounded-circle">
                        </a>
                        <div class="dropdown-menu dropdown-menu-end p-2">
                            <div class="d-flex align-items-center dropdown-item py-2 bg-secondary-subtle">
                                <div class="flex-shrink-0">
                                    <img src="<?php echo e(session('user.avatar') ?: asset('assets/images/default-avatar.jpg')); ?>" alt="" class="thumb-md rounded-circle">
                                </div>
                                <div class="flex-grow-1 ms-2 text-truncate align-self-center">
                                    <h6 class="my-0 fw-medium text-dark fs-13">
                                        <?php echo e(session('user.full_name') ?? session('user.username') ?? 'Agent'); ?>

                                    </h6>
                                    <small class="text-muted mb-0"><?php echo e(session('user.email') ?? 'No email'); ?></small>
                                </div>
                            </div>
                            <div class="dropdown-divider mt-0"></div>
                            <small class="text-muted px-2 pb-1 d-block">Account</small>
                            <a class="dropdown-item" href="#">
                                <i class="las la-cog fs-18 me-1 align-text-bottom"></i>Account Settings
                            </a>
                            <a class="dropdown-item text-danger" href="#"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="las la-power-off fs-18 me-1 align-text-bottom"></i> <b>Logout</b>
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                </ul><!--end topbar-nav-->
            </nav>
        </div>
    </div>
    <!-- Top Bar End -->
<?php /**PATH C:\xampp\htdocs\evalia\resources\views/agent/layouts/topbar.blade.php ENDPATH**/ ?>