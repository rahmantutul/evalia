

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/user-dashboard.css')); ?>">
<style>
    /* Premium Dashboard Overrides */
    .dashboard-card {
        border-radius: 16px;
        border: 1px solid rgba(231, 234, 243, 0.7);
        box-shadow: 0 0.125rem 0.25rem rgba(140, 152, 164, 0.05) !important;
        transition: all 0.2s ease-in-out;
    }
    .dashboard-card:hover {
        box-shadow: 0 0.5rem 1.25rem rgba(140, 152, 164, 0.1) !important;
    }

    /* Metric Cards */
    .icon-circle {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.95rem;
    }
    .metric-value {
        font-size: 1.4rem;
        font-weight: 800;
        letter-spacing: -0.02em;
        color: #1e2022;
    }

    /* Focus Area Enhancements */
    .focus-area-card {
        border-top: 4px solid #0d6efd;
        position: relative;
    }
    .focus-area-card.system { border-top-color: #6c757d; }
    
    .task-item {
        padding: 0.85rem;
        border-radius: 10px;
        border: 1px solid transparent;
        transition: all 0.2s ease;
        background: #f8fafd;
    }
    .task-item:hover {
        background: #fff;
        border-color: #e7eaf3;
        box-shadow: 0 4px 10px rgba(0,0,0,0.03);
    }
    
    .skill-badge {
        font-size: 10px;
        padding: 3px 10px;
        border-radius: 6px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }
    .skill-communication { background-color: rgba(13, 110, 253, 0.08); color: #0d6efd; }
    .skill-process { background-color: rgba(25, 135, 84, 0.08); color: #198754; }
    .skill-knowledge { background-color: rgba(255, 193, 7, 0.08); color: #9e7a00; }

    /* Learning Resources */
    .resource-card {
        background: #fff;
        border: 1px solid #e7eaf3;
        border-radius: 12px;
        padding: 12px;
        transition: all 0.2s ease;
    }
    .resource-card:hover {
        border-color: #0d6efd;
        transform: translateY(-2px);
    }
    .video-thumbnail {
        height: 110px;
        border-radius: 8px;
        background: linear-gradient(135deg, #374bff 0%, #12c2e9 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }
    .play-icon {
        width: 36px;
        height: 36px;
        background: rgba(255,255,255,0.95);
        color: #0d6efd;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    /* Utilities */
    .chart-container { position: relative; height: 130px; }
    .tasks-list { max-height: 220px; overflow-y: auto; padding-right: 4px; }
    .tasks-list::-webkit-scrollbar { width: 4px; }
    .tasks-list::-webkit-scrollbar-thumb { background: #cbd5e0; border-radius: 10px; }
    
    .history-table-container { max-height: 320px; overflow-y: auto; }
    .improvement-badge {
        background: linear-gradient(135deg, #0d6efd 0%, #198754 100%);
        padding: 8px 16px;
        border-radius: 12px;
        font-weight: 700;
        font-size: 12px;
        box-shadow: 0 4px 12px rgba(13, 110, 253, 0.2);
        color: white;
    }

    .bg-soft-primary { background-color: rgba(13, 110, 253, 0.08) !important; }
    .bg-soft-success { background-color: rgba(25, 135, 84, 0.08) !important; }
    .bg-soft-warning { background-color: rgba(255, 193, 7, 0.08) !important; }
    
    body { overflow-x: hidden; background-color: #f9fafb; }
    .font-500 { font-weight: 500; }
    .extra-small { font-size: 10px; }
    .call-review-item {
        border-radius: 12px;
        border: 1px solid #e7eaf3;
        transition: all 0.2s ease;
        padding: 1rem;
    }
    .call-review-item:hover {
        border-color: #0d6efd;
        background-color: #f8fafd;
        transform: translateY(-2px);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
                <h4 class="page-title">Coaching & Growth Plan</h4>
                <div class="">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('agent.dashboard')); ?>">Evalia</a></li>
                        <li class="breadcrumb-item active">Coaching</li>
                    </ol>
                </div>                            
            </div><!--end page-title-box-->
        </div><!--end col-->
    </div><!--end row-->

    <!-- Compressed Progress Overview -->
    <div class="row g-2 mb-3">
        <!-- Overall Progress -->
        <div class="col-md-3">
            <div class="dashboard-card h-100">
                <div class="card-body p-2 px-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="text-muted mb-0 extra-small fw-bold">OVERALL PROGRESS</p>
                        <h5 class="fw-bold mb-0" style="color: #0d6efd !important;">70%</h5>
                    </div>
                    <div class="progress-container my-1" style="height: 6px; width: 100%; background-color: #e9ecef; border-radius: 10px; overflow: hidden;">
                        <div class="progress-fill" style="height: 100%; width: 70%; background-color: #0d6efd; border-radius: 10px;"></div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <small class="text-muted extra-small">Level 4 Agent</small>
                        <small class="text-primary extra-small fw-bold">3 left</small>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tasks -->
        <div class="col-md-3">
            <div class="dashboard-card h-100">
                <div class="card-body p-2 px-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted mb-0 extra-small fw-bold uppercase">TASKS DONE</p>
                            <h4 class="mb-0 fw-bold text-success">7/10</h4>
                        </div>
                        <div class="icon-circle bg-soft-success" style="width: 32px; height: 32px; font-size: 0.8rem;">
                            <i class="fas fa-check-double text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Score -->
        <div class="col-md-3">
            <div class="dashboard-card h-100">
                <div class="card-body p-2 px-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted mb-0 extra-small fw-bold uppercase">SCORE IMPROVE.</p>
                            <h4 class="mb-0 fw-bold text-primary">+15</h4>
                        </div>
                        <div class="icon-circle bg-soft-primary" style="width: 32px; height: 32px; font-size: 0.8rem;">
                            <i class="fas fa-chart-line text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Next Due -->
        <div class="col-md-3">
            <div class="dashboard-card h-100">
                <div class="card-body p-2 px-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted mb-0 extra-small fw-bold uppercase">NEXT DUE</p>
                            <h4 class="mb-0 fw-bold text-warning">Feb 15</h4>
                        </div>
                        <div class="icon-circle bg-soft-warning" style="width: 32px; height: 32px; font-size: 0.8rem;">
                            <i class="fas fa-calendar-alt text-warning"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Focus Areas -->
    

    <!-- Learning Resources & Practice -->
    <div class="row g-4 mb-4">
        <!-- Learning Resources -->
        <div class="col-md-8">
            <div class="dashboard-card h-100">
                <div class="card-header bg-white border-0 py-3">
                    <h6 class="fw-bold mb-0"><i class="fas fa-graduation-cap text-success me-2"></i>Learning Resources</h6>
                </div>
                <div class="card-body p-4">
                    <!-- Quick Tips -->
                    <h6 class="fw-bold small text-muted mb-3">SHORT TIPS (TEXT)</h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <div class="alert alert-info border-0 mb-0">
                                <h6 class="fw-bold small mb-1"><i class="fas fa-lightbulb me-1"></i> Active Listening Trick</h6>
                                <p class="small mb-0">Repeat the customer's last 2-3 words to show you're engaged and encourage them to elaborate.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="alert alert-success border-0 mb-0">
                                <h6 class="fw-bold small mb-1"><i class="fas fa-check me-1"></i> Script Mastery</h6>
                                <p class="small mb-0">Use the "hamburger method": Script → Personal touch → Script to sound natural yet compliant.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Micro Videos -->
                    <h6 class="fw-bold small text-muted mb-3">MICRO-VIDEOS (1-3 MIN)</h6>
                    <div class="row g-3 mb-4">
                        <!-- Video 1 -->
                        <div class="col-md-4">
                            <div class="resource-card cursor-pointer js-video-popup" data-video-id="8K19oXZyAAU" data-title="Handling Angry Customers">
                                <div class="video-thumbnail mb-2">
                                    <div class="play-icon">
                                        <i class="fas fa-play"></i>
                                    </div>
                                </div>
                                <h6 class="fw-bold small mb-1">Handling Angry Customers</h6>
                            </div>
                        </div>
                        <!-- Video 2 -->
                        <div class="col-md-4">
                            <div class="resource-card cursor-pointer js-video-popup" data-video-id="Eq7Z2i7m57Y" data-title="Verification Best Practices">
                                <div class="video-thumbnail mb-2" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                                    <div class="play-icon">
                                        <i class="fas fa-play"></i>
                                    </div>
                                </div>
                                <h6 class="fw-bold small mb-1">Verification Best Practices</h6>
                            </div>
                        </div>
                        <!-- Video 3 -->
                        <div class="col-md-4">
                            <div class="resource-card cursor-pointer js-video-popup" data-video-id="q11TFTK2-FM" data-title="Building Rapport Quickly">
                                <div class="video-thumbnail mb-2" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                                    <div class="play-icon">
                                        <i class="fas fa-play"></i>
                                    </div>
                                </div>
                                <h6 class="fw-bold small mb-1">Building Rapport Quickly</h6>
                            </div>
                        </div>
                    </div>

                    <!-- Do/Don't Examples -->
                    <h6 class="fw-bold small text-muted mb-3">DO / DON'T EXAMPLES</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="p-3 border border-success rounded bg-soft-success">
                                <h6 class="fw-bold small text-success mb-2"><i class="fas fa-check-circle me-1"></i> DO</h6>
                                <p class="small mb-0">"I understand how frustrating this must be for you, [Name]. Let me make sure I fix this right away."</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 border border-danger rounded bg-soft-danger">
                                <h6 class="fw-bold small text-danger mb-2"><i class="fas fa-times-circle me-1"></i> DON'T</h6>
                                <p class="small mb-0">"That's not my fault. You should have read the terms and conditions before signing up."</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Practice & Self-Review -->
        <div class="col-md-4">
            <div class="dashboard-card h-100">
                <div class="card-header bg-white border-0 py-3 d-flex justify-content-between">
                    <h6 class="fw-bold mb-0"><i class="fas fa-headphones text-warning me-2"></i>Practice Section</h6>
                </div>
                <div class="card-body p-4">
                    <h6 class="fw-bold small text-muted mb-3">RECOMMENDED CALLS TO RE-LISTEN</h6>
                    
                    <div class="call-review-item mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="fw-bold small">Call #CUS-3301</span>
                            <span class="badge bg-soft-danger text-danger">Score: 72</span>
                        </div>
                        <p class="extra-small text-muted mb-2">Focus on: Empathy & Mirroring</p>
                        <button class="btn btn-sm btn-white border w-100 shadow-sm" onclick="playMockCall('CUS-3301', 'Empathy Training', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3')">
                            <i class="fas fa-play me-1 text-primary"></i> Listen & Self-Review
                        </button>
                    </div>

                    <div class="call-review-item mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="fw-bold small">Call #CUS-4402</span>
                            <span class="badge bg-soft-warning text-warning">Score: 78</span>
                        </div>
                        <p class="extra-small text-muted mb-2">Focus on: Technical Accuracy</p>
                        <button class="btn btn-sm btn-white border w-100 shadow-sm" onclick="playMockCall('CUS-4402', 'Product Knowledge', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3')">
                            <i class="fas fa-play me-1 text-primary"></i> Analyze Interaction
                        </button>
                    </div>

                    <div class="call-review-item">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="fw-bold small">Call #CUS-1120</span>
                            <span class="badge bg-soft-success text-success">Score: 92</span>
                        </div>
                        <p class="extra-small text-muted mb-2">Example of: Positive Closing</p>
                        <button class="btn btn-sm btn-white border w-100 shadow-sm" onclick="playMockCall('CUS-1120', 'Gold Standard Example', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3')">
                            <i class="fas fa-play me-1 text-primary"></i> Review Gold Example
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- History: Previous Coaching Plans -->
    
</div>

<!-- Video Modal -->
<div class="modal fade" id="videoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-dark text-white py-2 border-0">
                <h6 class="modal-title fw-bold" id="videoModalLabel">Coaching Video</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="ratio ratio-16x9 h-100">
                    <iframe id="videoPlayer" src="" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Audio Player Modal -->
<div class="modal fade" id="audioModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header py-2 border-0 bg-primary text-white">
                <h6 class="modal-title fw-bold" id="audioModalLabel">Practice Audio</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4 text-center">
                <div class="mb-3">
                    <i class="fas fa-headphones fa-3x text-primary shadow-sm p-3 rounded-circle bg-soft-primary"></i>
                </div>
                <h6 id="audioCallId" class="fw-bold mb-1">Call #CUS-0000</h6>
                <p id="audioFocus" class="small text-muted mb-4">Focus Area: Performance Review</p>
                <div class="bg-light p-3 rounded-3">
                    <audio id="audioPlayer" controls class="w-100">
                        <source src="" type="audio/mpeg">
                        Your browser does not support the audio element.
                    </audio>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Mini Trend Chart
    const chartElement = document.getElementById('scoreTrendChart');
    if (chartElement) {
        const ctx = chartElement.getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: [{
                    label: 'Score',
                    data: [72, 76, 82, 87],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true,
                    pointRadius: 4,
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#0d6efd',
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1e293b',
                        padding: 8,
                        cornerRadius: 6
                    }
                },
                scales: {
                    x: { 
                        grid: { display: false },
                        ticks: { font: { size: 9 } }
                    },
                    y: { 
                        min: 60,
                        max: 100,
                        grid: { borderDash: [3, 3], color: '#e2e8f0' },
                        ticks: { stepSize: 10, font: { size: 9 } }
                    }
                }
            }
        });
    }

    // Video Modal Logic
    const videoModalEl = document.getElementById('videoModal');
    const videoPlayer = document.getElementById('videoPlayer');
    const videoModalLabel = document.getElementById('videoModalLabel');

    if (videoModalEl && videoPlayer) {
        const videoModal = new bootstrap.Modal(videoModalEl);

        document.querySelectorAll('.js-video-popup').forEach(trigger => {
            trigger.addEventListener('click', function() {
                const videoId = this.getAttribute('data-video-id');
                const title = this.getAttribute('data-title');
                
                if (videoModalLabel) videoModalLabel.textContent = title;
                videoPlayer.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
                videoModal.show();
            });
        });

        // Clean up when modal closes
        videoModalEl.addEventListener('hidden.bs.modal', function () {
            videoPlayer.src = '';
        });
    }

    // Audio Modal Logic
    const audioModalEl = document.getElementById('audioModal');
    const audioPlayer = document.getElementById('audioPlayer');
    const audioModalLabel = document.getElementById('audioModalLabel');
    const audioCallId = document.getElementById('audioCallId');
    const audioFocus = document.getElementById('audioFocus');

    if (audioModalEl && audioPlayer) {
        const audioModal = new bootstrap.Modal(audioModalEl);

        window.playMockCall = function(id, focus, url) {
            audioCallId.textContent = `Call #${id}`;
            audioFocus.textContent = `Focus Area: ${focus}`;
            audioPlayer.src = url;
            audioPlayer.load();
            audioModal.show();
            audioPlayer.play();
        };

        // Clean up when modal closes
        audioModalEl.addEventListener('hidden.bs.modal', function () {
            audioPlayer.pause();
            audioPlayer.src = '';
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('agent.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/agent/coaching.blade.php ENDPATH**/ ?>