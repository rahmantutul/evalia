

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-tasks me-2"></i>Jobs
                    </h5>
                </div>
                <div class="card-body">
                    <!-- Simple Filters -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <form method="GET" action="<?php echo e(url('/hamsa/jobs')); ?>" class="row g-3">
                                <div class="col-md-4">
                                    <input type="text" name="search" class="form-control" 
                                           placeholder="Search jobs..." value="<?php echo e(request('search')); ?>">
                                </div>
                                
                                <div class="col-md-3">
                                    <select name="type" class="form-select">
                                        <option value="">All Types</option>
                                        <?php $__currentLoopData = $availableTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type); ?>" <?php echo e(request('type') == $type ? 'selected' : ''); ?>>
                                                <?php echo e($type); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-3">
                                    <select name="status" class="form-select">
                                        <option value="">All Statuses</option>
                                        <?php $__currentLoopData = $availableStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                                                <?php echo e($status); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Jobs List -->
                    <?php if(!empty($jobs)): ?>
                        <div class="row">
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h6 class="card-title text-truncate" title="<?php echo e($job['title'] ?? 'No title'); ?>">
                                                <?php echo e($job['title'] ?? 'No title'); ?>

                                            </h6>
                                            <span class="badge 
                                                <?php if($job['status'] == 'COMPLETED'): ?> bg-success
                                                <?php elseif($job['status'] == 'FAILED'): ?> bg-danger
                                                <?php elseif($job['status'] == 'PROCESSING'): ?> bg-info
                                                <?php else: ?> bg-warning <?php endif; ?>">
                                                <?php echo e($job['status']); ?>

                                            </span>
                                        </div>
                                        
                                        <div class="mb-2">
                                            <span class="badge bg-light text-dark"><?php echo e($job['type']); ?></span>
                                        </div>
                                        
                                        <div class="small text-muted mb-3">
                                            <div>Created: <?php echo e(\Carbon\Carbon::parse($job['createdAt'])->format('M j, Y H:i')); ?></div>
                                            <?php if(isset($job['cost'])): ?>
                                            <div>Cost: <?php echo e($job['cost']); ?> credits</div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted font-monospace">
                                                <?php echo e(substr($job['id'], 0, 8)); ?>...
                                            </small>
                                            <div class="btn-group">
                                                <a href="<?php echo e(url('/hamsa/jobs/' . $job['id'])); ?>" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if($job['status'] === 'COMPLETED' && isset($job['url'])): ?>
                                                    <a href="<?php echo e($job['url']); ?>" 
                                                       class="btn btn-sm btn-outline-success"
                                                       target="_blank">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                            <?php if(isset($pagination['totalPages']) && $pagination['totalPages'] > 1): ?>
                                <div class="d-flex justify-content-between align-items-center mt-4">
                                    <div class="text-muted small">
                                        Showing <?php echo e($pagination['skip'] + 1); ?> to 
                                        <?php echo e(min($pagination['skip'] + $pagination['filtered'], $pagination['total'])); ?> 
                                        of <?php echo e($pagination['total']); ?> results
                                    </div>
                                    <div class="d-flex gap-2">
                                        <?php if($pagination['page'] > 1): ?>
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['page' => $pagination['page'] - 1])); ?>" 
                                            class="btn btn-sm btn-outline-primary">Previous</a>
                                        <?php endif; ?>
                                        <?php if($pagination['page'] < $pagination['totalPages']): ?>
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['page' => $pagination['page'] + 1])); ?>" 
                                            class="btn btn-sm btn-outline-primary">Next</a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-center mt-3">
                                    <nav>
                                        <ul class="pagination pagination-sm mb-0">
                                            <?php
                                                $currentPage = $pagination['page'];
                                                $totalPages = $pagination['totalPages'];
                                                $startPage = max(1, $currentPage - 2);
                                                $endPage = min($totalPages, $currentPage + 2);
                                            ?>

                                            <?php if($startPage > 1): ?>
                                                <li class="page-item">
                                                    <a class="page-link" href="<?php echo e(request()->fullUrlWithQuery(['page' => 1])); ?>">1</a>
                                                </li>
                                                <?php if($startPage > 2): ?>
                                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php for($i = $startPage; $i <= $endPage; $i++): ?>
                                                <li class="page-item <?php echo e($i == $currentPage ? 'active' : ''); ?>">
                                                    <a class="page-link" href="<?php echo e(request()->fullUrlWithQuery(['page' => $i])); ?>"><?php echo e($i); ?></a>
                                                </li>
                                            <?php endfor; ?>

                                            <?php if($endPage < $totalPages): ?>
                                                <?php if($endPage < $totalPages - 1): ?>
                                                    <li class="page-item disabled"><span class="page-link">...</span></li>
                                                <?php endif; ?>
                                                <li class="page-item">
                                                    <a class="page-link" href="<?php echo e(request()->fullUrlWithQuery(['page' => $totalPages])); ?>"><?php echo e($totalPages); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </nav>
                                </div>
                            <?php endif; ?>


                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                            <h5>No jobs found</h5>
                            <p class="text-muted mb-4">
                                <?php if(request()->anyFilled(['search', 'type', 'status'])): ?>
                                    No jobs match your current filters.
                                <?php else: ?>
                                    No jobs have been created yet.
                                <?php endif; ?>
                            </p>
                            <a href="<?php echo e(url('/hamsa/transcribe')); ?>" class="btn btn-primary">
                                Create First Job
                            </a>
                        </div>
                    <?php endif; ?>

                    <?php if($error): ?>
                        <div class="alert alert-danger mt-3">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <?php echo e($error); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/hamsa/jobs.blade.php ENDPATH**/ ?>