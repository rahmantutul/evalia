
<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('/')); ?>assets/css/dashboard.css" rel="stylesheet" type="text/css" />
    <style>
        /* Statistics cards styling */
        .stat-card {
            border-radius: 12px;
            padding: 1.25rem;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            height: 100%;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.07) !important;
        }
        
        /* Tooltip styling */
        .action-btn {
            position: relative;
            margin-left: 5px;
        }

        .action-btn:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }

        .tooltip-text {
            visibility: hidden;
            width: max-content;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 3px 6px;
            position: absolute;
            z-index: 1;
            top: -30px;
            right: 50%;
            transform: translateX(50%);
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 12px;
            white-space: nowrap;
        }

        .table td .btn-group {
            float: right;
        }
    </style>
     <style>
    .btn-group {
        display: flex;
        gap: 8px;
    }

    .btn-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border-radius: 6px;
        color: #6c757d;
        background: #e8eff5;
        transition: all 0.2s ease;
        text-decoration: none;
        position: relative;
    }

    .btn-icon:hover {
        background: #e9ecef;
        color: #495057;
        transform: translateY(-1px);
    }

    .btn-icon:hover::after {
        content: attr(title);
        position: absolute;
        bottom: 40px;
        left: 50%;
        transform: translateX(-50%);
        background: #333;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 100;
    }

    .btn-delete:hover {
        background: #dc3545;
        color: white;
    }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Group List Section -->
    <div class="row mb-4 mt-3">
        <div class="col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col d-flex justify-content-between align-items-center">                      
                            <h4 class="card-title mb-0">Group List</h4>
                        <a href="<?php echo e(route('user.group_data.create')); ?>" type="button" class="btn btn-sm btn-primary">
                                Create New 
                            </a>                   
                        </div>

                    </div>                                 
                </div>
                <div class="card-body pt-0">
                    <div class="table-responsive">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                       <table class="table mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Group ID</th>
                                <th>Group Name</th>
                                <th>Group description</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($paginatedGroups) > 0): ?>
                                <?php $__currentLoopData = $paginatedGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($group['group_id']); ?></td>
                                        <td><?php echo e($group['group_name']); ?></td> 
                                        <td><?php echo e($group['description']); ?></td> 
                                        <td>
                                            <span class="badge bg-success">Active</span>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('user.group_data.details',$group['group_id'])); ?>" class="btn btn-icon" title="Settings">
                                                    <i class="fas fa-cogs"></i>
                                                </a>
                                                <a href="<?php echo e(route('user.group_data.delete', $group['group_id'])); ?>" onclick="return confirm('Are you sure to delete this?')" class="btn btn-icon btn-delete" title="Delete">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4">No groups found.</td>
                                </tr>
                            <?php endif; ?>         
                        </tbody>
                    </table>

                    <!-- Pagination Section -->
                    <?php if(isset($pagination) && $pagination['total'] > $pagination['per_page']): ?>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div class="text-muted">
                                Showing <?php echo e($pagination['from']); ?> to <?php echo e($pagination['to']); ?> of <?php echo e($pagination['total']); ?> entries
                            </div>
                            <nav>
                                <ul class="pagination mb-0">
                                    <!-- Previous Page Link -->
                                    <li class="page-item <?php echo e($pagination['current_page'] == 1 ? 'disabled' : ''); ?>">
                                        <a class="page-link" href="?page=<?php echo e($pagination['current_page'] - 1); ?>&limit=<?php echo e($pagination['per_page']); ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>

                                    <!-- Page Numbers -->
                                    <?php for($i = 1; $i <= $pagination['last_page']; $i++): ?>
                                        <li class="page-item <?php echo e($pagination['current_page'] == $i ? 'active' : ''); ?>">
                                            <a class="page-link" href="?page=<?php echo e($i); ?>&limit=<?php echo e($pagination['per_page']); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>

                                    <!-- Next Page Link -->
                                    <li class="page-item <?php echo e($pagination['current_page'] == $pagination['last_page'] ? 'disabled' : ''); ?>">
                                        <a class="page-link" href="?page=<?php echo e($pagination['current_page'] + 1); ?>&limit=<?php echo e($pagination['per_page']); ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    <?php endif; ?>                           
                    </div>
                </div>
            </div>
        </div>       
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia_old\resources\views/user/group/group_list.blade.php ENDPATH**/ ?>