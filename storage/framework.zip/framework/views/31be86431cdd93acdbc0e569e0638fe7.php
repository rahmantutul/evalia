<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center mb-4 mt-3">
        <div class="col-md-10">
            <div class="card shadow-lg border-0" style="border-radius: 20px;">
                <div class="card-header bg-white py-4 border-0">
                    <div class="d-flex align-items-center">
                        <div class="bg-primary p-3 rounded-4 me-3 shadow-sm">
                            <i class="fas fa-book-open text-white fa-xl"></i>
                        </div>
                        <div>
                            <h4 class="card-title mb-0 fw-bold text-dark">Add New Knowledge Base</h4>
                            <p class="text-muted mb-0">Add descriptive text and keywords for AI context</p>
                        </div>
                    </div>
                </div>

                <div class="card-body px-5 pb-5">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger border-0 shadow-sm mb-4" style="border-radius: 10px;">
                            <i class="fas fa-exclamation-triangle me-2"></i> <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('user.knowledgeBase.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row g-4">
                            <!-- Company Selection -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-dark">Select Company <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-0"><i class="icofont-bank-alt"></i></span>
                                    <select name="company_id" class="form-select border-0 bg-light py-2" style="border-radius: 0 10px 10px 0;" required>
                                        <option value="" disabled selected>Select a company...</option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->company_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger mt-1 d-block"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Title -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-dark">KB Title <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-0"><i class="fas fa-heading"></i></span>
                                    <input type="text" name="title" class="form-control border-0 bg-light py-2" placeholder="e.g. Greeting Protocols" style="border-radius: 0 10px 10px 0;" required>
                                </div>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger mt-1 d-block"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Content / Description -->
                            <div class="col-12">
                                <label class="form-label fw-bold text-dark">Knowledge Details (Text) <span class="text-danger">*</span></label>
                                <div class="position-relative">
                                    <textarea name="content" id="kbContent" class="form-control border-0 bg-light" rows="10" 
                                        placeholder="Paste the rules, procedures or information here..." 
                                        style="border-radius: 15px;" maxlength="5000" required></textarea>
                                    <div class="position-absolute bottom-0 end-0 p-2 text-muted small">
                                        <span id="charCount">0</span>/5000
                                    </div>
                                </div>
                                <small class="text-muted mt-1 d-block">This is the main information Gemini will use to evaluate calls.</small>
                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger mt-1 d-block"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Keywords -->
                            <div class="col-12">
                                <label class="form-label fw-bold text-dark">Keywords (Search Tags)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-0"><i class="fas fa-tags"></i></span>
                                    <input type="text" name="keywords" class="form-control border-0 bg-light py-2" 
                                        placeholder="e.g. greeting, opening, introduction (comma separated)" 
                                        style="border-radius: 0 10px 10px 0;">
                                </div>
                                <small class="text-muted mt-1 d-block">Adding keywords helps the search engine find this entry more accurately during analysis.</small>
                                <?php $__errorArgs = ['keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger mt-1 d-block"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Submit -->
                            <div class="col-12 mt-5">
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <a href="<?php echo e(route('user.knowledgeBase.list')); ?>" class="btn btn-light px-5 py-2 fw-bold" style="border-radius: 12px;">Cancel</a>
                                    <button type="submit" class="btn btn-primary px-5 py-2 fw-bold" style="border-radius: 12px; transition: 0.3s;" id="submitBtn">
                                        <i class="fas fa-save me-2"></i> Save Knowledge Entry
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .form-control:focus, .form-select:focus {
        background-color: #fff !important;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.1) !important;
        border: 1px solid #0d6efd !important;
    }
    
    .tagify {
        border: none !important;
        background: #f8f9fa;
        border-radius: 0 10px 10px 0 !important;
        padding: 5px 10px !important;
    }
    .tagify--focus {
        background: #fff !important;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.1) !important;
    }
    .tagify__tag {
        margin: 2px !important;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const kbContent = document.getElementById('kbContent');
    const charCount = document.getElementById('charCount');

    kbContent.addEventListener('input', function() {
        charCount.textContent = this.value.length;
    });

    // Initialize Tagify
    const keywordsInput = document.querySelector('input[name="keywords"]');
    const tagify = new Tagify(keywordsInput, {
        originalInputValueFormat: valuesArr => valuesArr.map(item => item.value).join(',')
    });

    document.querySelector('form').addEventListener('submit', function() {
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Saving...';
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/user/knowledgeBase/create.blade.php ENDPATH**/ ?>