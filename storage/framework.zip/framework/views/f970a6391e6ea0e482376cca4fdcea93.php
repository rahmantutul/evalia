<!DOCTYPE html>
 <html lang="en" dir="ltr" data-startbar="light" data-bs-theme="light">

<head>
    <meta charset="utf-8" />
   <title>Dashboard | Evalia</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Evalia" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/preview.png')); ?>" type="image/png">
    <link rel="icon" href="<?php echo e(asset('assets/images/preview.png')); ?>" type="image/png">

    <!-- For different devices and browsers -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/preview.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/preview.png')); ?>">
    <!-- CSS Files -->
    <link href="<?php echo e(asset('/')); ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/css/custom.css" rel="stylesheet" type="text/css" />

    <style>
        /* Initial hide to prevent Flash of Unstyled Content (FOUC) */
        html { visibility: hidden; opacity: 0; }
        html.loaded { visibility: visible; opacity: 1; transition: opacity 0.1s ease-out; }

        /* Global Reset for the 'Everything shows a big border' issue */
        *, *::before, *::after {
            box-sizing: border-box;
            outline: none !important;
            -webkit-tap-highlight-color: transparent;
        }

        /* Prevent sidebar and navbar from animating/snapping on load */
        .startbar, .navbar, .startbar-menu {
            transition: none !important;
        }

        /* Fix the 'skeleton border' flash on Iconoir icons during load */
        [class*=" iconoir-"]::before, [class^=iconoir-]::before {
            stroke-width: 1.5px !important;
        }

        /* Smooth out the sidebar border by ensuring it matches theme defaults immediately */
        .startbar .startbar-menu .navbar-nav .nav-item .nav-link::before {
            transition: none !important;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.documentElement.classList.add('loaded');
        });
        // Fallback for slow loads
        setTimeout(function() {
            document.documentElement.classList.add('loaded');
        }, 300);
    </script>
    <link href="<?php echo e(asset('/')); ?>assets/libs/mobius1-selectr/selectr.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/libs/huebee/huebee.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/libs/vanillajs-datepicker/css/datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>assets/libs/simple-datatables/style.css" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <?php if(session('user.role.name') === 'Supervisor'): ?>
        <?php echo $__env->make('supervisor.layouts.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('supervisor.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('user.layouts.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('user.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <div class="startbar-overlay d-print-none"></div>

    <div class="page-wrapper">
        <div class="page-content">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('user.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <!-- JavaScript Files -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/simplebar/simplebar.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="https://apexcharts.com/samples/assets/stock-prices.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/js/pages/index.init.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/mobius1-selectr/selectr.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/huebee/huebee.pkgd.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/vanillajs-datepicker/js/datepicker-full.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/js/moment.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/imask/imask.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/js/pages/forms-advanced.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/js/app.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/libs/simple-datatables/umd/simple-datatables.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/js/pages/datatable.init.js"></script>  
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
     <script src="https://cdn.tailwindcss.com"></script>
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: <?php echo json_encode(session('success')); ?>,
                timer: 3000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: <?php echo json_encode(session('error')); ?>,
                timer: 4000,
                showConfirmButton: true,
                position: 'center'
            });
        </script>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Validation Error',
                html: `<ul class="text-start small mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </ul>`,
                confirmButtonText: 'Correct Errors'
            });
        </script>
    <?php endif; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const switcher = document.querySelector('.bot-switcher');
        const btn = document.querySelector('.bot-switcher-btn');
        
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            switcher.classList.toggle('active');
        });
        
        document.addEventListener('click', function() {
            switcher.classList.remove('active');
        });
    });
    </script>
    <script>
        // Global error handler for authentication failures
        document.addEventListener('DOMContentLoaded', function() {
            // Override fetch to handle auth errors
            const originalFetch = window.fetch;
            window.fetch = function(...args) {
                return originalFetch.apply(this, args)
                    .then(response => {
                        if (response.status === 401 || response.status === 403) {
                            // Redirect to login immediately
                            window.location.href = '<?php echo e(route("login")); ?>?session_expired=1';
                            return Promise.reject(new Error('Authentication failed'));
                        }
                        return response;
                    })
                    .catch(error => {
                        // If it's a network error but we have a session, check if we should redirect
                        if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
                            // Only redirect if we believe we should be authenticated
                            setTimeout(() => {
                                window.location.href = '<?php echo e(route("login")); ?>?connection_error=1';
                            }, 1000);
                        }
                        throw error;
                    });
            };
        });

        // Handle any uncaught errors that might be auth-related
        window.addEventListener('unhandledrejection', function(event) {
            if (event.reason && 
                (event.reason.status === 401 || 
                event.reason.status === 403 ||
                event.reason.message.includes('Failed to fetch'))) {
                event.preventDefault();
                window.location.href = '<?php echo e(route("login")); ?>?session_expired=1';
            }
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\evalia\resources\views/user/layouts/app.blade.php ENDPATH**/ ?>