
<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('/')); ?>assets/css/dashboard.css" rel="stylesheet" type="text/css" />
    <style>
        /* Tooltip styling */
        .action-btn {
            position: relative;
            margin-left: 5px;
        }

        .action-btn:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }

        .tooltip-text {
            visibility: hidden;
            width: max-content;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 3px 6px;
            position: absolute;
            z-index: 1;
            top: -30px;
            right: 50%;
            transform: translateX(50%);
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 12px;
            white-space: nowrap;
        }

        .table td .btn-group {
            display: flex;
            float: left;
        }
        
        /* Sticky Statistics Bar Styles */
        .sticky-top-bar {
            transition: all 0.3s ease;
            top: 20px;
        }
        
        .sticky-top-bar.sticky-active {
            position: sticky;
            top: 0;
            z-index: 1020;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .stat-item {
            border-right: 1px solid #e9ecef;
            padding-right: 15px;
        }
        
        .stat-item:last-child {
            border-right: none;
            padding-right: 0;
        }
        
        @media (max-width: 768px) {
            .stat-item {
                border-right: none;
                border-bottom: 1px solid #e9ecef;
                padding-right: 0;
                padding-bottom: 10px;
                margin-bottom: 10px;
            }
            
            .stat-item:last-child {
                border-bottom: none;
                margin-bottom: 0;
                padding-bottom: 0;
            }
        }
    </style>
     <style>
    .btn-group {
        display: flex;
        gap: 8px;
    }

    .btn-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border-radius: 6px;
        color: #6c757d;
        background: #e8eff5;
        transition: all 0.2s ease;
        text-decoration: none;
        position: relative;
    }

    .btn-icon:hover {
        background: #e9ecef;
        color: #495057;
        transform: translateY(-1px);
    }

    .btn-icon:hover::after {
        content: attr(title);
        position: absolute;
        bottom: 40px;
        left: 50%;
        transform: translateX(-50%);
        background: #333;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 100;
    }

    .btn-delete:hover {
        background: #dc3545;
        color: white;
    }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Sticky Statistics Bar -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm sticky-top-bar">
                <div class="card-body py-3">
                    <div class="row g-3">
                        <!-- Total Companies -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-building text-primary me-2"></i>
                                <div>
                                    <h6 class="mb-0 fw-bold" id="totalCompanies">0</h6>
                                    <p class="text-muted small mb-0" style="font-size: 10px;">Companies</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Active Tasks -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-tasks text-success me-2"></i>
                                <div>
                                    <h6 class="mb-0 fw-bold" id="activeTasks">0</h6>
                                    <p class="text-muted small mb-0" style="font-size: 10px;">Active Tasks</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Completed Tasks -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-check-circle text-info me-2"></i>
                                <div>
                                    <h6 class="mb-0 fw-bold" id="completedTasks">0</h6>
                                    <p class="text-muted small mb-0" style="font-size: 10px;">Completed</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Pending Analysis -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-clock text-warning me-2"></i>
                                <div>
                                    <h6 class="mb-0 fw-bold" id="pendingAnalysis">0</h6>
                                    <p class="text-muted small mb-0" style="font-size: 10px;">Pending</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Total Agents -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-users text-secondary me-2"></i>
                                <div>
                                    <h6 class="mb-0 fw-bold" id="totalAgents">0</h6>
                                    <p class="text-muted small mb-0" style="font-size: 10px;">Agents</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Success Rate -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-star text-danger me-2"></i>
                                <div>
                                    <h6 class="mb-0 fw-bold" id="averageQuality">0%</h6>
                                    <p class="text-muted small mb-0" style="font-size: 10px;">Quality Score</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Company List -->
    <div class="row mb-4 mt-3">
        <div class="col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="col d-flex justify-content-between align-items-center">                      
                        <h4 class="card-title mb-0">Company List</h4>
                         <?php if(session('user.role.name') !== 'Supervisor'): ?>
                        <a href="<?php echo e(route('user.company.create')); ?>" class="btn btn-sm btn-primary d-block float-end">+ Create New</a>                  
                        <?php endif; ?>
                    </div>                                 
                </div>
                <div class="card-body pt-0">
                    <div class="table-responsive">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?> 

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <table class="table datatable mb-0" id="datatable_1">
                            <thead class="table-light">
                                <tr>
                                    <th>Company Name</th>
                                    <th>Industry Sector</th>
                                    <th>Agents</th>
                                    <th style="text-align: center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $totalCompanies = count($companies);
                                    
                                ?>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        // Use real count from controller
                                        $agentsCount = $company['agents_count'] ?? 0;
                                        
                                        // Default sources fallback if not in DB
                                        $defaultSources = ['api'];
                                        if ($company['id'] == 'arab-bank') {
                                            $defaultSources[] = 'genesys';
                                        }
                                    ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('user.company.view', $company['id'])); ?>" class="fw-bold text-primary">
                                                <?php echo e($company['name']); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($company['group_name'] ?? 'Private Sector'); ?></td>
                                        <td><?php echo e($agentsCount); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('user.company.view',$company['id'])); ?>" class="btn btn-icon" title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('user.task.list',$company['id'])); ?>" class="btn btn-icon" title="Task List">
                                                    <i class="fas fa-list"></i>
                                                </a>
                                                  <?php if(session('user.role.name') !== 'Supervisor'): ?>
                                                <a href="<?php echo e(route('user.company.edit',$company['id'])); ?>" class="btn btn-icon" title="Settings">
                                                    <i class="fas fa-cogs"></i>
                                                </a>
                                                <a href="<?php echo e(route('user.company.delete',$company['id'])); ?>" onclick="return confirm('Are you sure to delete this?')" class="btn btn-icon btn-delete" title="Delete">
                                                    <i class="fas fa-trash-alt"></i>
                                                </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>

                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                            </tbody>
                        </table>                                             
                    </div>
                </div>
            </div>
        </div>       
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Use actual statistics from controller
        const stats = {
            totalCompanies: <?php echo json_encode(count($companies), 15, 512) ?>,
            activeTasks: <?php echo json_encode($totalActiveTasks ?? 0, 15, 512) ?>,
            completedTasks: <?php echo json_encode($totalCompletedTasks ?? 0, 15, 512) ?>,
            pendingAnalysis: <?php echo json_encode($totalPendingAnalysis ?? 0, 15, 512) ?>,
            totalAgents: <?php echo json_encode($totalAgentsCount ?? 0, 15, 512) ?>,
            averageQuality: <?php echo json_encode($avgQaScore ?? 0, 15, 512) ?>
        };

        // Animate counting up for each statistic
        function animateCounter(elementId, finalValue, suffix = '') {
            const element = document.getElementById(elementId);
            let current = 0;
            const increment = finalValue > 0 ? finalValue / 50 : 0;
            const timer = setInterval(() => {
                current += increment;
                if (current >= finalValue) {
                    current = finalValue;
                    clearInterval(timer);
                }
                
                let val = Math.floor(current);
                if (suffix === '%') {
                    element.textContent = val + suffix;
                } else if (elementId === 'activeTasks' && val === 0) {
                    element.textContent = '00';
                } else {
                    element.textContent = val.toLocaleString();
                }
            }, 30);
        }

        // Start animations
        animateCounter('totalCompanies', stats.totalCompanies);
        animateCounter('activeTasks', stats.activeTasks);
        animateCounter('completedTasks', stats.completedTasks);
        animateCounter('pendingAnalysis', stats.pendingAnalysis);
        animateCounter('totalAgents', stats.totalAgents);
        animateCounter('averageQuality', stats.averageQuality, '%');

        // Make the statistics bar sticky when scrolling
        const stickyBar = document.querySelector('.sticky-top-bar');
        const originalOffsetTop = stickyBar.offsetTop;
        
        function handleScroll() {
            if (window.pageYOffset > originalOffsetTop) {
                stickyBar.classList.add('sticky-active');
            } else {
                stickyBar.classList.remove('sticky-active');
            }
        }
        
        window.addEventListener('scroll', handleScroll);

        // Add CSS for sticky behavior
        const style = document.createElement('style');
        style.textContent = `
            .sticky-top-bar.sticky-active {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                z-index: 1020;
                margin: 0 15px;
                width: calc(100% - 30px);
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                animation: slideDown 0.3s ease;
            }
            
            @keyframes slideDown {
                from {
                    transform: translateY(-100%);
                    opacity: 0;
                }
                to {
                    transform: translateY(0);
                    opacity: 1;
                }
            }
            
            .stat-item {
                transition: transform 0.2s ease;
            }
            
            .stat-item:hover {
                transform: translateY(-2px);
            }
        `;
        document.head.appendChild(style);
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/user/company/company_list.blade.php ENDPATH**/ ?>