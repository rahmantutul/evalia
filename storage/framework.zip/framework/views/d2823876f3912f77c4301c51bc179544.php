

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Header -->
    <div class="row m-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1">Criteria Management</h4>
                    <p class="text-muted mb-0">Manage your matching criteria for sales people and clients</p>
                </div>
                <a href="<?php echo e(route('criteria.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus-circle mr-2"></i>Add Criteria
                </a>
            </div>
        </div>
    </div>

    <!-- Criteria List -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Criteria Name</th>
                                    <th>Description</th>
                                    <th>Type</th>
                                    <th width="100" class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="font-weight-600 text-dark"><?php echo e($criterion['title']); ?></div>
                                    </td>
                                    <td>
                                        <span class="text-muted"><?php echo e($criterion['description']); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-light border text-black"><?php echo e($criterion['type']); ?></span>
                                    </td>
                                    <td class="text-center">
                                        <div class="action-buttons">
                                            <a href="#" class="btn btn-sm btn-outline-primary mr-1" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button class="btn btn-sm btn-outline-danger" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.font-weight-600 {
    font-weight: 600;
}
.action-buttons .btn {
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
}
.table th {
    border-top: none;
    font-weight: 600;
    color: #495057;
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/criteria/index.blade.php ENDPATH**/ ?>