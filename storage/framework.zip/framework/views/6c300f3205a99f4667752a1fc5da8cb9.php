

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="col d-flex justify-content-between align-items-center">
                        <h4 class="card-title mb-0">User Details</h4>
                        <div class="btn-group">
                            
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-sm btn-secondary">
                                <i class="fas fa-arrow-left me-1"></i>Back to List
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="card-title mb-0">Basic Information</h5>
                                </div>
                                <div class="card-body">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td class="text-muted" width="30%">Full Name:</td>
                                            <td class="fw-bold"><?php echo e($user['full_name'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Email:</td>
                                            <td class="fw-bold"><?php echo e($user['email']); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Username:</td>
                                            <td class="fw-bold"><?php echo e($user['username']); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Status:</td>
                                            <td>
                                                <span class="badge <?php echo e($user['is_active'] ? 'bg-success' : 'bg-danger'); ?>">
                                                    <?php echo e($user['is_active'] ? 'Active' : 'Inactive'); ?>

                                                </span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="card-title mb-0">Professional Information</h5>
                                </div>
                                <div class="card-body">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td class="text-muted" width="30%">Role:</td>
                                            <td>
                                                <span class="btn btn-sm  btn-success"><?php echo e($user['role']['name'] ?? 'N/A'); ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Position:</td>
                                            <td class="fw-bold"><?php echo e($user['position'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Phone:</td>
                                            <td class="fw-bold"><?php echo e($user['phone'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-muted">Company ID:</td>
                                            <td class="fw-bold"><?php echo e($user['company_id'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <?php if($user['supervisor_id']): ?>
                                        <tr>
                                            <td class="text-muted">Supervisor ID:</td>
                                            <td class="fw-bold"><?php echo e($user['supervisor_id']); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/user/users/show.blade.php ENDPATH**/ ?>