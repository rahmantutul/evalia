
<?php $__env->startPush('styles'); ?>
<style>
    /* Tooltip styling */
    .action-btn {
        position: relative;
        margin-left: 5px;
    }

    .action-btn:hover .tooltip-text {
        visibility: visible;
        opacity: 1;
    }

    .tooltip-text {
        visibility: hidden;
        width: max-content;
        background-color: #333;
        color: #fff;
        text-align: center;
        border-radius: 5px;
        padding: 3px 6px;
        position: absolute;
        z-index: 1;
        top: -30px;
        right: 50%;
        transform: translateX(50%);
        opacity: 0;
        transition: opacity 0.3s;
        font-size: 12px;
        white-space: nowrap;
    }

    .table td .btn-group {
        float: right;
    }
    
    /* Sticky Statistics Bar Styles */
    .sticky-top-bar {
        transition: all 0.3s ease;
        top: 20px;
    }
    
    .sticky-top-bar.sticky-active {
        position: sticky;
        top: 0;
        z-index: 1020;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .stat-item {
        border-right: 1px solid #e9ecef;
        padding-right: 15px;
    }
    
    .stat-item:last-child {
        border-right: none;
        padding-right: 0;
    }
    
    @media (max-width: 768px) {
        .stat-item {
            border-right: none;
            border-bottom: 1px solid #e9ecef;
            padding-right: 0;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        
        .stat-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
    }
</style>
<style>
.btn-group {
    display: flex;
    gap: 8px;
}

.btn-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 6px;
    color: #6c757d;
    background: #e8eff5;
    transition: all 0.2s ease;
    text-decoration: none;
    position: relative;
}

.btn-icon:hover {
    background: #e9ecef;
    color: #495057;
    transform: translateY(-1px);
}

.btn-icon:hover::after {
    content: attr(title);
    position: absolute;
    bottom: 40px;
    left: 50%;
    transform: translateX(-50%);
    background: #333;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    white-space: nowrap;
    z-index: 100;
}

.btn-delete:hover {
    background: #dc3545;
    color: white;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Sticky Statistics Bar -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm sticky-top-bar">
                <div class="card-body py-3">
                    <div class="row g-3">
                        <!-- Total Agents -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 bg-primary bg-opacity-10 p-3 rounded me-3">
                                    <i class="fas fa-users text-primary fs-5"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-0 fw-bold" id="totalAgents">0</h5>
                                    <small class="text-muted">Total Agents</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Active Agents -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 bg-success bg-opacity-10 p-3 rounded me-3">
                                    <i class="fas fa-user-check text-success fs-5"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-0 fw-bold" id="activeAgents">0</h5>
                                    <small class="text-muted">Active Agents</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Average Rating -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 bg-warning bg-opacity-10 p-3 rounded me-3">
                                    <i class="fas fa-star text-warning fs-5"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-0 fw-bold" id="averageRating">0.0</h5>
                                    <small class="text-muted">Avg Rating</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Total Calls -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 bg-info bg-opacity-10 p-3 rounded me-3">
                                    <i class="fas fa-phone-alt text-info fs-5"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-0 fw-bold" id="totalCalls">0</h5>
                                    <small class="text-muted">Total Calls</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Success Rate -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 bg-danger bg-opacity-10 p-3 rounded me-3">
                                    <i class="fas fa-chart-line text-danger fs-5"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-0 fw-bold" id="successRate">0%</h5>
                                    <small class="text-muted">Success Rate</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Response Time -->
                        <div class="col-md-2 col-sm-4 col-6 stat-item">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 bg-secondary bg-opacity-10 p-3 rounded me-3">
                                    <i class="fas fa-clock text-secondary fs-5"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-0 fw-bold" id="avgResponseTime">0s</h5>
                                    <small class="text-muted">Avg Response Time</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Agent List -->
    <div class="row mb-4 mt-3">
        <div class="col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="col d-flex justify-content-between align-items-center">                      
                        <h4 class="card-title mb-0">Agent List</h4>
                        <a href="<?php echo e(route('user.agent.create')); ?>" class="btn btn-sm btn-primary d-block float-end">+ Add Agent</a>                  
                    </div>                                 
                </div>
                <div class="card-body pt-0">
                    <div class="table-responsive">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?> 

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <table class="table datatable mb-0" id="datatable_1">
                            <thead class="table-light">
                                <tr>
                                    <th>Agent ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Company</th>
                                    <th style="text-align: center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>AG-1001</td>
                                    <td>Abdullah Al Hasib</td>
                                    <td>abdullah@example.com</td>
                                    <td>+1 (555) 111-2222</td>
                                    <td>Tech Innovators</td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('user.agent.details')); ?>" class="btn btn-icon" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.edit')); ?>" class="btn btn-icon" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.delete')); ?>" onclick="return confirm('Are you sure to delete this?')" class="btn btn-icon btn-delete" title="Delete">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>AG-1002</td>
                                    <td>Sarah Johnson</td>
                                    <td>sarah@example.com</td>
                                    <td>+1 (555) 333-4444</td>
                                    <td>Finance Corp</td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('user.agent.details')); ?>" class="btn btn-icon" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.edit')); ?>" class="btn btn-icon" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.delete')); ?>" onclick="return confirm('Are you sure to delete this?')" class="btn btn-icon btn-delete" title="Delete">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>AG-1003</td>
                                    <td>Michael Smith</td>
                                    <td>michael@example.com</td>
                                    <td>+1 (555) 555-6666</td>
                                    <td>Healthcare Plus</td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('user.agent.details')); ?>" class="btn btn-icon" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.edit')); ?>" class="btn btn-icon" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.delete')); ?>" onclick="return confirm('Are you sure to delete this?')" class="btn btn-icon btn-delete" title="Delete">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>AG-1004</td>
                                    <td>Emma Brown</td>
                                    <td>emma@example.com</td>
                                    <td>+1 (555) 777-8888</td>
                                    <td>Edu Global</td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('user.agent.details', 1004)); ?>" class="btn btn-icon" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.edit', 1004)); ?>" class="btn btn-icon" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.delete', 1004)); ?>" onclick="return confirm('Are you sure to delete this?')" class="btn btn-icon btn-delete" title="Delete">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>AG-1005</td>
                                    <td>David Wilson</td>
                                    <td>david@example.com</td>
                                    <td>+1 (555) 999-0000</td>
                                    <td>Logistics Hub</td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('user.agent.details', 1005)); ?>" class="btn btn-icon" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.edit', 1005)); ?>" class="btn btn-icon" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?php echo e(route('user.agent.delete', 1005)); ?>" onclick="return confirm('Are you sure to delete this?')" class="btn btn-icon btn-delete" title="Delete">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>                                             
                    </div>
                </div>
            </div>
        </div>       
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Generate fake statistics data for agents
        const fakeStats = {
            totalAgents: 5, // From the table rows
            activeAgents: Math.floor(Math.random() * 3) + 3, // Random between 3-5
            averageRating: (Math.random() * 2 + 3).toFixed(1), // Random between 3.0-5.0
            totalCalls: Math.floor(Math.random() * 1000) + 500, // Random between 500-1500
            successRate: Math.floor(Math.random() * 30) + 65, // Random between 65-95
            avgResponseTime: Math.floor(Math.random() * 20) + 5 // Random between 5-25
        };

        // Animate counting up for each statistic
        function animateCounter(elementId, finalValue, suffix = '', isDecimal = false) {
            const element = document.getElementById(elementId);
            let current = 0;
            const increment = finalValue / 50; // Adjust speed here
            const timer = setInterval(() => {
                current += increment;
                if (current >= finalValue) {
                    current = finalValue;
                    clearInterval(timer);
                }
                
                if (isDecimal) {
                    element.textContent = current.toFixed(1) + suffix;
                } else if (suffix === '%') {
                    element.textContent = Math.floor(current) + suffix;
                } else {
                    element.textContent = Math.floor(current).toLocaleString() + suffix;
                }
            }, 30);
        }

        // Start animations
        animateCounter('totalAgents', fakeStats.totalAgents);
        animateCounter('activeAgents', fakeStats.activeAgents);
        animateCounter('averageRating', parseFloat(fakeStats.averageRating), '', true);
        animateCounter('totalCalls', fakeStats.totalCalls);
        animateCounter('successRate', fakeStats.successRate, '%');
        animateCounter('avgResponseTime', fakeStats.avgResponseTime, 's');

        // Make the statistics bar sticky when scrolling
        const stickyBar = document.querySelector('.sticky-top-bar');
        const originalOffsetTop = stickyBar.offsetTop;
        
        function handleScroll() {
            if (window.pageYOffset > originalOffsetTop) {
                stickyBar.classList.add('sticky-active');
            } else {
                stickyBar.classList.remove('sticky-active');
            }
        }
        
        window.addEventListener('scroll', handleScroll);
    });
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia_old\resources\views/user/agent/agent_list.blade.php ENDPATH**/ ?>