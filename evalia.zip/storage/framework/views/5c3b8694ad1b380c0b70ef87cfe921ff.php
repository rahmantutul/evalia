

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="card shadow-lg border-0 rounded-3 overflow-hidden">
        <!-- Card Header with Gradient Background -->
        <div class="card-header bg-gradient-primary-to-secondary text-white py-3">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <i class="bi bi-building me-3 fs-2"></i>
                    <div>
                        <h2 class="mb-0">Company Analytics Dashboard</h2>
                        <p class="mb-0 opacity-75">Detailed insights for <?php echo e($company['company_id'] ?? 'N/A'); ?></p>
                    </div>
                </div>
                <a href="<?php echo e(route('user.company.list')); ?>" class="btn btn-light btn-sm rounded-pill px-3">
                    <i class="bi bi-arrow-left me-1"></i> Back to List
                </a>
            </div>
        </div>

        <div class="card-body p-4">
            <!-- Stats Overview Row -->
            <div class="row mb-4 g-4">
                <!-- Main Topics Card -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-blue text-white">
                            <h5 class="mb-0"><i class="bi bi-list-task me-2"></i>Main Topics</h5>
                        </div>
                        <div class="card-body">
                            <?php if(!empty($company['main_topics'])): ?>
                                <div class="mt-3">
                                    <?php $__currentLoopData = $company['main_topics']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex justify-content-between py-1 border-bottom">
                                            <span><?php echo e(Str::limit($topic, 25)); ?></span>
                                            <span class="badge bg-primary rounded-pill"><?php echo e($count); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-info-circle fs-1"></i>
                                    <p class="mt-2 mb-0">No main topics available</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Call Types Card -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-purple text-white">
                            <h5 class="mb-0"><i class="bi bi-telephone me-2"></i>Call Types</h5>
                        </div>
                        <div class="card-body">
                            <?php if(!empty($company['call_types'])): ?>
                                <div class="mt-3">
                                    <?php $__currentLoopData = $company['call_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex justify-content-between py-1 border-bottom">
                                            <span><?php echo e(Str::title(str_replace('_', ' ', $type))); ?></span>
                                            <span class="badge bg-purple rounded-pill"><?php echo e($count); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-info-circle fs-1"></i>
                                    <p class="mt-2 mb-0">No call types available</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Performance Overview Card -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-green text-white">
                            <h5 class="mb-0"><i class="bi bi-speedometer2 me-2"></i>Performance</h5>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-6 mb-3">
                                    <div class="p-3 bg-light rounded">
                                        <h6 class="mb-1 text-muted">Avg Delay</h6>
                                        <h4 class="mb-0 text-primary">
                                            <?php echo e(round(array_sum($company['delay_classes'] ?? []) / max(count($company['delay_classes'] ?? []), 1))); ?>s
                                        </h4>
                                    </div>
                                </div>
                                <div class="col-6 mb-3">
                                    <div class="p-3 bg-light rounded">
                                        <h6 class="mb-1 text-muted">Avg Pause</h6>
                                        <h4 class="mb-0 text-success">
                                            <?php echo e(round(array_sum($company['pause_classes'] ?? []) / max(count($company['pause_classes'] ?? []), 1))); ?>s
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <h6 class="text-muted mb-2">Call Outcomes</h6>
                                <?php if(!empty($company['call_outcomes'])): ?>
                                    <div class="d-flex flex-wrap gap-2">
                                        <?php $__currentLoopData = $company['call_outcomes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-success rounded-pill px-3 py-1">
                                                <i class="bi bi-check-circle me-1"></i>
                                                <?php echo e(ucwords(str_replace('_',' ', $outcome))); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted small">No call outcomes recorded</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Detailed Metrics Row -->
            <div class="row g-4">
                <!-- Delay Metrics -->
                <div class="col-md-6">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-orange text-white">
                            <h5 class="mb-0"><i class="bi bi-stopwatch me-2"></i>Delay Metrics</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th>Delay Type</th>
                                            <th class="text-end">Seconds</th>
                                            <th class="text-end">% of Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $totalDelay = array_sum($company['delay_classes'] ?? []);
                                        ?>
                                        <?php $__currentLoopData = $company['delay_classes'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(ucfirst($k)); ?></td>
                                                <td class="text-end"><?php echo e($v); ?>s</td>
                                                <td class="text-end">
                                                    <?php echo e($totalDelay > 0 ? round(($v/$totalDelay)*100, 1) : 0); ?>%
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(empty($company['delay_classes'])): ?>
                                            <tr>
                                                <td colspan="3" class="text-center text-muted py-3">
                                                    No delay data available
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pause Metrics -->
                <div class="col-md-6">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-pink text-white">
                            <h5 class="mb-0"><i class="bi bi-pause-circle me-2"></i>Pause Metrics</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th>Pause Type</th>
                                            <th class="text-end">Seconds</th>
                                            <th class="text-end">% of Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $totalPause = array_sum($company['pause_classes'] ?? []);
                                        ?>
                                        <?php $__currentLoopData = $company['pause_classes'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(ucfirst($k)); ?></td>
                                                <td class="text-end"><?php echo e($v); ?>s</td>
                                                <td class="text-end">
                                                    <?php echo e($totalPause > 0 ? round(($v/$totalPause)*100, 1) : 0); ?>%
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(empty($company['pause_classes'])): ?>
                                            <tr>
                                                <td colspan="3" class="text-center text-muted py-3">
                                                    No pause data available
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Agent Configurations Row -->
            <div class="row mt-4 g-4">
                <!-- Performance Configs -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-indigo text-white">
                            <h5 class="mb-0"><i class="bi bi-person-check me-2"></i>Performance Configs</h5>
                        </div>
                        <div class="card-body">
                            <?php if(!empty($company['agent_performance_configs'])): ?>
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $company['agent_performance_configs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex align-items-center">
                                            <i class="bi bi-check-circle-fill text-success me-2"></i>
                                            <?php echo e(ucwords(str_replace('_', ' ', $item))); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-slash-circle fs-1"></i>
                                    <p class="mt-2 mb-0">No performance configurations</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Cooperation Configs -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-teal text-white">
                            <h5 class="mb-0"><i class="bi bi-people me-2"></i>Cooperation Configs</h5>
                        </div>
                        <div class="card-body">
                            <?php if(!empty($company['agent_cooperation_configs'])): ?>
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $company['agent_cooperation_configs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex align-items-center">
                                            <i class="bi bi-arrow-left-right text-info me-2"></i>
                                            <?php echo e(ucwords(str_replace('_', ' ', $item))); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-slash-circle fs-1"></i>
                                    <p class="mt-2 mb-0">No cooperation configurations</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Assessment Configs -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-header bg-light-cyan text-white">
                            <h5 class="mb-0"><i class="bi bi-clipboard-data me-2"></i>Assessment Configs</h5>
                        </div>
                        <div class="card-body">
                            <?php if(!empty($company['agent_assessments_configs'])): ?>
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $company['agent_assessments_configs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex align-items-center">
                                            <i class="bi bi-bar-chart-line text-warning me-2"></i>
                                            <?php echo e(ucwords(str_replace('_', ' ', $item))); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-slash-circle fs-1"></i>
                                    <p class="mt-2 mb-0">No assessment configurations</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card Footer -->
        <div class="card-footer bg-light py-3">
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted">
                    Last updated: <?php echo e(now()->format('M d, Y \a\t h:i A')); ?>

                </small>
                <div>
                    <button class="btn btn-sm btn-outline-primary me-2">
                        <i class="bi bi-download me-1"></i> Export
                    </button>
                    <button class="btn btn-sm btn-primary">
                        <i class="bi bi-printer me-1"></i> Print
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Scripts -->
<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Main Topics Chart
    <?php if(!empty($company['main_topics'])): ?>
    const topicsCtx = document.getElementById('topicsChart').getContext('2d');
    const topicsChart = new Chart(topicsCtx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode(array_keys($company['main_topics'])); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($company['main_topics'])); ?>,
                backgroundColor: [
                    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', 
                    '#e74a3b', '#858796', '#5a5c69', '#2e59d9'
                ],
                hoverBorderColor: "#fff",
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            cutout: '70%'
        }
    });
    <?php endif; ?>

    // Call Types Chart
    <?php if(!empty($company['call_types'])): ?>
    const callTypesCtx = document.getElementById('callTypesChart').getContext('2d');
    const callTypesChart = new Chart(callTypesCtx, {
        type: 'pie',
        data: {
            labels: <?php echo json_encode(array_map(function($k) { 
                return Str::title(str_replace('_', ' ', $k)); 
            }, array_keys($company['call_types']))); ?>,
            datasets: [{
                data: <?php echo json_encode(array_values($company['call_types'])); ?>,
                backgroundColor: [
                    '#6610f2', '#6f42c1', '#d63384', '#fd7e14',
                    '#20c997', '#0dcaf0', '#ffc107', '#0d6efd'
                ],
                hoverBorderColor: "#fff",
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<style>
    /* Custom gradient backgrounds */
    .bg-gradient-primary-to-secondary {
        background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
    }
    h5{
        color: #000;
        font-size: 18px;
    }
    
    /* Card hover effects */
    .card {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    
    /* Custom list group items */
    .list-group-item {
        transition: background-color 0.2s ease;
    }

</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kayan\resources\views/user/company_details.blade.php ENDPATH**/ ?>