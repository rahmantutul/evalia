
<?php $__env->startPush('styles'); ?>
<style>
  /* Lightweight color scheme */
  :root {
    --primary: #4361ee;
    --primary-light: #e6e9ff;
    --success: #2ecc71;
    --success-light: #e8f8f0;
    --warning: #f39c12;
    --warning-light: #fef5e6;
    --danger: #e74c3c;
    --danger-light: #fdedec;
    --dark: #2c3e50;
    --light: #f8f9fa;
    --gray: #95a5a6;
  }

  /* Base styles */
  .professional-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    padding: 1.5rem;
    height: 100%;
    transition: transform 0.2s, box-shadow 0.2s;
    border: 1px solid #eee;
  }

  .professional-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
  }

  .card-header {
    font-weight: 600;
    color: var(--dark);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 1.1rem;
  }

  /* Top bar */
  .top-bar {
    background: white;
    border-radius: 8px;
    padding: 0.75rem 1.5rem;
    margin-bottom: 1.5rem;
    display: flex;
    gap: 2rem;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    border: 1px solid #eee;
  }

  .duration {
    display: flex;
    align-items: center;
    color: var(--dark);
    font-weight: 500;
  }

  /* Toggle switch */
  .toggle-switch {
    position: relative;
    display: inline-block;
    width: 180px;
    height: 34px;
    margin-bottom: 1.5rem;
  }

  .toggle-switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .toggle-slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: var(--primary);
    transition: .4s;
    border-radius: 34px;
  }

  .toggle-slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: .4s;
    border-radius: 50%;
  }

  input:checked + .toggle-slider {
    background-color: var(--primary);
  }

  input:checked + .toggle-slider:before {
    transform: translateX(146px);
  }

  .toggle-label {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    color: white;
    font-size: 12px;
    font-weight: 500;
  }

  .toggle-label.left {
    left: 15px;
  }

  .toggle-label.right {
    right: 15px;
  }

  /* Sentiment bar */
  .sentiment-bar-container {
    padding: 0.5rem 0;
  }

  .sentiment-bar {
    height: 10px;
    background: linear-gradient(90deg, var(--success) 40%, var(--warning) 55%, var(--danger) 80%);
    border-radius: 5px;
    margin: 1rem 0;
    position: relative;
  }

  .sentiment-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.8rem;
    color: var(--gray);
  }

  /* WPM card */
  .wpm-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 2rem;
    background: linear-gradient(135deg, var(--primary-light) 0%, white 100%);
  }

  .wpm-value {
    font-size: 3.5rem;
    font-weight: 700;
    color: var(--primary);
    line-height: 1;
    margin: 0.5rem 0;
  }

  .wpm-unit {
    color: var(--gray);
    font-size: 0.9rem;
  }

  /* Tables */
  .sentiment-table, .pause-delay-table {
    width: 100%;
    border-collapse: collapse;
  }

  .sentiment-table th, .pause-delay-table th {
    text-align: left;
    padding: 0.75rem;
    font-weight: 500;
    color: var(--gray);
    font-size: 0.85rem;
    border-bottom: 1px solid #eee;
  }

  .sentiment-table td, .pause-delay-table td {
    padding: 0.75rem;
    border-bottom: 1px solid #eee;
    vertical-align: middle;
  }

  /* Audio player */
  .audio-player {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding-top: 15px;
    padding-left: 20px;
    padding-right: 20px;
    
  }

  .audio-controls {
    display: flex;
    gap: 0.5rem;
  }

  .audio-btn {
    border: none;
    color: var(--color-red-500);
    font-size: 1.2rem;
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .audio-btn:hover {
    background: var(--primary-light);
  }

  .audio-progress {
    flex-grow: 1;
    height: 6px;
    background: #eee;
    border-radius: 3px;
    position: relative;
    cursor: pointer;
  }

  .audio-progress-filled {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 30%;
    background: var(--primary);
    border-radius: 3px;
  }

  .audio-time {
    font-size: 0.8rem;
    color: var(--gray);
    min-width: 70px;
    text-align: center;
  }

  /* Summary & Transcription */
  .summary-section {
    background: var(--light);
    padding: 1rem;
    border-radius: 8px;
    font-size: 0.95rem;
    line-height: 1.6;
    color: var(--dark);
    white-space: pre-line;
    margin-bottom: 1rem;
  }

  .transcription-textarea {
    width: 100%;
    min-height: 200px;
    border: 1px solid #eee;
    border-radius: 8px;
    padding: 1rem;
    font-family: inherit;
    font-size: 0.9rem;
    line-height: 1.6;
    resize: none;
    background: var(--light);
  }

  .translated-container {
    margin-top: 1rem;
    border-top: 1px solid #eee;
    padding-top: 1rem;
  }

  .translated-header {
    font-weight: 500;
    color: var(--dark);
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .translated-content {
    font-size: 0.9rem;
    color: var(--gray);
    line-height: 1.6;
    white-space: pre-line;
  }

  /* Loudness bars */
  .loudness-bars {
    padding: 1rem 0;
  }

  .loudness-bar {
    margin-bottom: 1rem;
  }

  .loudness-bar-label {
    font-size: 0.9rem;
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .loudness-bar-fill {
    height: 10px;
    border-radius: 5px;
  }

  .loudness-low {
    width: 58%;
    background: var(--danger);
  }

  .loudness-optimal {
    width: 0%;
    background: var(--success);
  }

  .loudness-high {
    width: 41%;
    background: var(--warning);
  }

  .loudness-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.8rem;
    color: var(--gray);
    margin-top: 0.5rem;
  }

  /* Animations */
  .animate-fade {
    animation: fadeIn 0.5s ease-out forwards;
  }

  .delay-1 { animation-delay: 0.1s; opacity: 0; }
  .delay-2 { animation-delay: 0.2s; opacity: 0; }
  .delay-3 { animation-delay: 0.3s; opacity: 0; }
  .delay-4 { animation-delay: 0.4s; opacity: 0; }

  @keyframes fadeIn {
    to { opacity: 1; }
  }

  /* Tooltip icon */
  .info-icon {
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background: var(--primary-light);
    color: var(--primary);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.7rem;
    cursor: help;
  }
</style>

<style>
  .audio-controls {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;
    margin-bottom: 15px;
  }

  .audio-btn {
    background: none;
    border: none;
    font-size: 20px;
    cursor: pointer;
    color: #495057;
    transition: color 0.2s;
  }

  .audio-btn:hover {
    color: #0d6efd;
  }

  .audio-progress {
    height: 6px;
    background: #e9ecef;
    border-radius: 3px;
    margin-bottom: 10px;
    cursor: pointer;
  }

  .audio-progress-filled {
    height: 100%;
    background: #0d6efd;
    border-radius: 3px;
    width: 0%;
    transition: width 0.1s;
  }

  .audio-time {
    display: flex;
    justify-content: space-between;
    font-size: 14px;
    color: #6c757d;
  }
</style>

<style>
  .transcription-container {
    max-height: 450px;
    overflow-y: auto;
    padding: 10px;
  }
  .transcript-line {
    margin-bottom: 8px;
    padding: 5px;
    border-radius: 4px;
    background-color: #f8f9fa;
  }
  .transcript-line .speaker {
    font-weight: bold;
    margin-right: 5px;
  }
  .transcript-line .speaker.agent {
    color: #0d6efd;
  }
  .transcript-line .speaker.customer {
    color: #fd7e14;
  }
  .timestamp {
    color: #6c757d;
    margin-right: 5px;
    font-size: 0.9em;
  }
  .sentiment-badge {
    float: right;
    font-size: 0.7em;
    padding: 3px 6px;
  }
</style>
<style>
.speech-rate-card {
  padding: 1.75rem;
  background: white;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.04);
  border: 1px solid rgba(0,0,0,0.04);
}

.card-header {
  padding: 0;
  background: transparent;
  border: none;
}

.info-badge {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #888;
  cursor: pointer;
  transition: all 0.3s ease;
}

.info-badge:hover {
  color: #555;
}



.pace-line {
  position: absolute;
  height: 30px;
  width: 1px;
  background: rgba(0,0,0,0.1);
  top: -35px;
  transform: translateX(-50%);
}

.pace-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin-top: 2.5rem;
}

.stat-card {
  padding: 1.25rem;
  border-radius: 10px;
  background: #f9fafb;
  transition: all 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 5px 15px rgba(0,0,0,0.03);
}

.stat-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.85rem;
  color: #555;
  margin-bottom: 0.75rem;
}

.stat-icon {
  font-size: 1.1rem;
}

.stat-value {
  font-size: 1.75rem;
  font-weight: 600;
  line-height: 1.2;
}

.stat-value small {
  font-size: 1rem;
  font-weight: 400;
  color: #888;
}

.stat-difference {
  font-size: 0.8rem;
  margin-top: 0.25rem;
  color: #666;
}

.card-footer {
  padding: 0;
  background: transparent;
  border: none;
}
</style>
<style>
.compact-volume-line {
  padding: 1rem;
  background: white;
  border-radius: 8px;
  border: 1px solid #eaeaea;
  box-shadow: 0 1px 3px rgba(0,0,0,0.03);
}

.volume-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.75rem;
}
.volume-metrics {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
}

.metric-box {
  flex: 1;
  text-align: center;
  padding: 0.5rem;
  border-radius: 6px;
  background: #f9f9f9;
  transition: all 0.2s ease;
}

.metric-box:hover {
  background: #f0f0f0;
  transform: translateY(-2px);
}

.metric-icon {
  font-size: 1.1rem;
  margin-bottom: 0.2rem;
}

.metric-value {
  font-weight: 600;
  font-size: 1rem;
  line-height: 1.2;
}

.metric-label {
  font-size: 0.75rem;
  color: #666;
  margin-top: 0.1rem;
}

/* Color coding */
.low .metric-icon,
.low .metric-value { color: #3498db; }

.optimal .metric-icon,
.optimal .metric-value { color: #2ecc71; }

.high .metric-icon,
.high .metric-value { color: #e67e22; }
</style>
<style>
.compact-speech-card {
  padding: 1rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  border: 1px solid #f0f0f0;
}

.card-title {
  font-size: 0.95rem;
  font-weight: 500;
}

.info-icon {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #f5f5f5;
  color: #888;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.7rem;
  cursor: help;
}

.speech-rate-line {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
}

.rate-box {
  flex: 1;
  text-align: center;
  padding: 0.5rem;
  border-radius: 6px;
  background: #f9f9f9;
}

.rate-icon {
  font-size: 1.2rem;
  margin-bottom: 0.2rem;
}

.rate-value {
  font-weight: 600;
  font-size: 1.1rem;
  line-height: 1.2;
}

.rate-label {
  font-size: 0.75rem;
  color: #666;
  margin: 0.1rem 0 0.2rem;
}

.rate-comparison {
  font-size: 0.8rem;
}

.divider {
  width: 1px;
  height: 40px;
  background: #eee;
}

.agent .rate-icon,
.agent .rate-value { color: #3498db; }

.customer .rate-icon,
.customer .rate-value { color: #2ecc71; }

.speech-summary {
  font-size: 0.8rem;
  text-align: center;
  padding-top: 0.5rem;
  border-top: 1px solid #f5f5f5;
}

.bi-arrow-up { color: #f39c12; }
.bi-arrow-down { color: #2ecc71; }
.bi-dash { color: #95a5a6; }
</style>
<style>
.compact-sentiment-card {
  padding: 1rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  border: 1px solid #f0f0f0;
}

.card-title {
  font-size: 0.95rem;
  font-weight: 500;
}

.info-icon {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #f5f5f5;
  color: #888;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.7rem;
  cursor: help;
}

.sentiment-line {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
}

.sentiment-box {
  flex: 1;
  text-align: center;
  padding: 0.5rem;
  border-radius: 6px;
  background: #f9f9f9;
}

.sentiment-icon {
  font-size: 1.2rem;
  margin-bottom: 0.2rem;
}

.sentiment-value {
  font-weight: 600;
  font-size: 1.1rem;
  line-height: 1.2;
}

.sentiment-label {
  font-size: 0.75rem;
  color: #666;
  margin: 0.1rem 0 0.2rem;
}

.divider {
  width: 1px;
  height: 40px;
  background: #eee;
}

/* Color coding */
.positive .sentiment-icon,
.positive .sentiment-value { color: #2ecc71; }
.neutral .sentiment-icon,
.neutral .sentiment-value { color: #f39c12; }
.negative .sentiment-icon,
.negative .sentiment-value { color: #e74c3c; }

.sentiment-summary {
  font-size: 0.8rem;
  padding-top: 0.5rem;
  border-top: 1px solid #f5f5f5;
}
</style>
<style>
.time-analysis-card {
  background: white;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  height: 100%;
  display: flex;
  flex-direction: column;
}

.nav-tabs {
  padding: 0.75rem 1rem 0;
  border-bottom: 1px solid #f0f0f0;
}

.nav-tabs .nav-link {
  border: none;
  font-size: 0.85rem;
  font-weight: 500;
  color: #666;
  padding: 0.5rem 1rem;
  position: relative;
}

.nav-tabs .nav-link.active {
  color: #3b82f6;
  background: transparent;
}

.nav-tabs .nav-link.active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  right: 0;
  height: 2px;
  background: #3b82f6;
}

.tab-content {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.table-container {
  flex: 1;
  overflow-y: auto;
  max-height: 300px;
  padding: 0 1rem;
}

.time-analysis-table {
  width: 100%;
  font-size: 0.85rem;
  border-collapse: separate;
  border-spacing: 0;
}

.time-analysis-table thead th {
  position: sticky;
  top: 0;
  background: white;
  padding: 0.75rem 0.5rem;
  font-weight: 500;
  color: #666;
  border-bottom: 1px solid #f0f0f0;
  z-index: 10;
}

.time-analysis-table tbody tr {
  border-bottom: 1px solid #f5f5f5;
}

.time-analysis-table tbody tr:last-child {
  border-bottom: none;
}

.time-analysis-table td {
  padding: 0.75rem 0.5rem;
  vertical-align: middle;
}

.time-analysis-table tbody tr:hover {
  background-color: #f9f9f9;
}

.text-truncate {
  max-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.badge {
  font-weight: 400;
  padding: 0.25rem 0.5rem;
}
</style>
<style>
.premium-summary {
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.05);
  border: 1px solid rgba(0,0,0,0.03);
  overflow: hidden;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.summary-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.25rem 1.5rem;
  background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
  border-bottom: 1px solid rgba(0,0,0,0.05);
}

.summary-title {
  display: flex;
  align-items: center;
}

.summary-title h5 {
  margin: 0;
  font-weight: 600;
  color: #333;
}

.summary-title i {
  color: #3b82f6;
  font-size: 1.2rem;
}

.summary-badge .badge {
  font-weight: 500;
  padding: 0.35rem 0.75rem;
  border-radius: 20px;
}

.summary-content {
  padding: 1.5rem;
}

.detailed-summary {
  background: #f9fafb;
  border-radius: 8px;
  padding: 1.25rem;
  border-left: 3px solid #3b82f6;
}

.summary-text {
  line-height: 1.7;
  color: #444;
  font-size: 0.95rem;
}

.arabic-text {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.key-points {
  background: #f9fafb;
  border-radius: 8px;
  padding: 1.25rem;
  margin-top: 1.5rem;
}

.section-title {
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
}

.section-title h6 {
  margin: 0 0 0 0.5rem;
  font-weight: 600;
  color: #333;
}

.section-title i {
  color: #f59e0b;
}

.points-list {
  padding-right: 1.5rem;
  margin: 0;
}

.points-list li {
  margin-bottom: 0.5rem;
  padding-right: 0;
  position: relative;
}

.topic-badge {
  display: inline-block;
  padding: 0.35rem 0.75rem;
  border-radius: 20px;
  font-weight: 500;
  margin-bottom: 1rem;
}

.main-badge {
  background-color: rgba(59, 130, 246, 0.1);
  color: #3b82f6;
}

.outcome-item {
  padding-top: 0.75rem;
  margin-top: 0.75rem;
  border-top: 1px dashed #e5e7eb;
}

.summary-footer {
  padding: 1rem 1.5rem;
  background: #f8fafc;
  border-top: 1px solid rgba(0,0,0,0.05);
}

.short-summary {
  font-style: italic;
  color: #666;
  line-height: 1.6;
  text-align: center;
  padding: 0.5rem;
}

@media (max-width: 768px) {
  .summary-header {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .summary-badge {
    margin-top: 0.5rem;
  }
}
</style>
<style>
.compact-key-points {
  font-size: 0.9rem;
  line-height: 1.6;
}

.points-line {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5rem;
}

.point-item {
  display: inline-flex;
  align-items: center;
  white-space: nowrap;
}

.point-divider {
  color: #ddd;
  font-weight: 300;
}

.outcome-line {
  display: flex;
  align-items: center;
  color: #444;
}

.arabic-text {
  direction: rtl;
  text-align: right;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.bi {
  font-size: 0.85rem;
}
</style>


<style>
.word-frequency-card {
  background: white;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
  border: 1px solid #f0f0f0;
  padding: 1.25rem;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.25rem;
}

.card-header h5 {
  margin: 0;
  font-weight: 600;
  color: #333;
}

.info-icon {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: #f5f5f5;
  color: #888;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.8rem;
  cursor: help;
}

.word-frequency-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
}

.speaker-words {
  background: #f9fafb;
  border-radius: 8px;
  padding: 1rem;
}

.speaker-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
  font-weight: 500;
  color: #444;
}

.speaker-header i {
  font-size: 1.1rem;
}

.agent-words .speaker-header i {
  color: #3b82f6;
}

.customer-words .speaker-header i {
  color: #10b981;
}

.word-cloud {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  line-height: 1.7;
}

.word-tag {
  background: white;
  border-radius: 10px;
  padding: 0.35rem 0.4rem;
  display: inline-flex;
  align-items: center;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  border: 1px solid #eee;
}

.frequency-badge {
  background: #f0f0f0;
  border-radius: 10px;
  padding: 0.1rem 0.2rem;
  font-size: 0.5rem;
  margin-left: 0.3rem;
  color: #666;
}
/* Arabic text styling */


@media (max-width: 768px) {
  .word-frequency-container {
    grid-template-columns: 1fr;
  }
}
</style>
<style>
.agent-performance-dashboard {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.08);
  padding: 24px;
  margin: 0 auto;
}

.dashboard-header {
  display: flex;
  justify-content: space-start;
  gap: 30px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.agent-profile {
  display: flex;
  gap: 20px;
  align-items: center;
  width: 400px;
}

.avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #f0f7ff 0%, #e1effe 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #3b82f6;
  font-size: 32px;
}

.agent-info h3 {
  margin: 0 0 10px 0;
  color: #1e3a8a;
  font-size: 24px;
}

.overall-score {
  display: flex;
  align-items: center;
  gap: 20px;
}

.score-circle {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: conic-gradient(#3b82f6 var(--percentage), #e2e8f0 var(--percentage));
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

.score-circle span {
  background: white;
  width: 70px;
  height: 70px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 18px;
  color: #1e3a8a;
}

.score-details {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.score-item {
  display: flex;
  justify-content: space-between;
  min-width: 180px;
}

.score-item .label {
  color: #64748b;
  font-weight: 500;
}

.score-item .value {
  font-weight: 600;
  color: #1e293b;
}

.speech-analysis {
  background: #f8fafc;
  border-radius: 12px;
  padding: 16px;
  flex: 1;
  max-width: 500px;
}

.speech-analysis h4 {
  margin-top: 0;
  color: #1e3a8a;
  font-size: 18px;
}

.speech-metrics {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.metric {
  display: flex;
  align-items: center;
  gap: 10px;
}

.metric i {
  color: #3b82f6;
  width: 20px;
  text-align: center;
}

.progress-bar {
  flex: 1;
  height: 8px;
  background: #e2e8f0;
  border-radius: 4px;
  overflow: hidden;
  min-width: 100px;
}

.progress {
  height: 100%;
  background: linear-gradient(90deg, #3b82f6, #6366f1);
  border-radius: 4px;
}

.tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.tab-btn {
  padding: 12px 20px;
  background: #f1f5f9;
  border: none;
  border-radius: 8px;
  font-weight: 500;
  color: #64748b;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s;
}

.tab-btn.active {
  background: #3b82f6;
  color: white;
}

.tab-btn i {
  font-size: 16px;
}

.tab-content {
  margin-bottom: 24px;
}

.tab-pane {
  display: none;
}

.tab-pane.active {
  display: block;
}

.metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
}

.metric-card {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 16px;
  transition: transform 0.2s, box-shadow 0.2s;
}

.metric-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.metric-score {
  font-size: 24px;
  font-weight: bold;
  color: #3b82f6;
  margin-bottom: 8px;
}

.metric-card h4 {
  margin: 0 0 12px 0;
  color: #1e293b;
  font-size: 16px;
}

.metric-details p {
  margin: 8px 0;
  font-size: 14px;
  color: #475569;
}

.metric-details strong {
  color: #1e293b;
}

.full-width-section {
  background: #f8fafc;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
}

.full-width-section h3 {
  margin-top: 0;
  color: #1e3a8a;
}

.tone-analysis {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.tone-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.tone-label {
  min-width: 100px;
  color: #1e293b;
  font-weight: 500;
}

.language-stats {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 16px;
}

.language-stats .stat {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid #e2e8f0;
}

.performance-summary {
  background: linear-gradient(135deg, #f0f7ff 0%, #e1effe 100%);
  border-radius: 12px;
  padding: 20px;
  border-left: 4px solid #3b82f6;
}

.summary-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.summary-header i {
  font-size: 24px;
  color: #3b82f6;
}

.summary-header h3 {
  margin: 0;
  color: #1e3a8a;
}

.summary-content p {
  margin: 0 0 12px 0;
  color: #475569;
  line-height: 1.5;
}

.summary-stats {
  display: flex;
  gap: 24px;
  margin-top: 12px;
}

.summary-stats .stat {
  display: flex;
  gap: 8px;
}

.summary-stats .stat span:first-child {
  font-weight: 500;
  color: #64748b;
}

.summary-stats .stat span:last-child {
  font-weight: 600;
  color: #1e293b;
}

@media (max-width: 768px) {
  .dashboard-header {
    flex-direction: column;
  }
  
  .metrics-grid {
    grid-template-columns: 1fr;
  }
  
  .score-details {
    width: 100%;
  }
  
  .tabs {
    overflow-x: auto;
    padding-bottom: 8px;
  }
  
  .tab-btn {
    white-space: nowrap;
  }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
  <!-- Top Call Duration Bar -->
  <div class="top-bar animate-fade">
    
    <div class="duration">
      <i class="bi bi-mic me-2"></i>Talking Duration: 
      <?php echo e($data['pause_delay_information']['talking_duration']['agent'] ?? 'N/A'); ?> (Agent) / 
      <?php echo e($data['pause_delay_information']['talking_duration']['customer'] ?? 'N/A'); ?> (Customer)
    </div>
  </div>

  <div class="row gy-4">
    <!-- Sentiment Analysis Card -->
    <div class="col-lg-4 animate-fade delay-1">
      <div class="compact-sentiment-card h-100">
        <div class="card-header d-flex justify-content-between align-items-center mb-3">
          <h6 class="card-title mb-0">Sentiment Analysis</h6>
          <div class="info-icon" data-bs-toggle="tooltip" title="Emotional tone measurement">i</div>
        </div>

        <?php
          // Initialize sentiment counters
          $agentSentiments = ['Positive' => 0, 'Neutral' => 0, 'Negative' => 0];
          $customerSentiments = ['Positive' => 0, 'Neutral' => 0, 'Negative' => 0];
          
          // Calculate agent sentiments
          if(isset($data['agent_speakers_transcriptions'])) {
            foreach($data['agent_speakers_transcriptions'] as $transcript) {
              $sentiment = $transcript['sentiment'] ?? 'Neutral';
              $agentSentiments[$sentiment]++;
            }
          }
          
          // Calculate customer sentiments
          if(isset($data['customer_speakers_transcriptions'])) {
            foreach($data['customer_speakers_transcriptions'] as $transcript) {
              $sentiment = $transcript['sentiment'] ?? 'Neutral';
              $customerSentiments[$sentiment]++;
            }
          }
          
          // Calculate totals
          $totalAgent = array_sum($agentSentiments);
          $totalCustomer = array_sum($customerSentiments);
          $total = $totalAgent + $totalCustomer;
          
          // Calculate percentages
          $positivePercent = $total > 0 ? round(($agentSentiments['Positive'] + $customerSentiments['Positive']) / $total * 100) : 0;
          $neutralPercent = $total > 0 ? round(($agentSentiments['Neutral'] + $customerSentiments['Neutral']) / $total * 100) : 0;
          $negativePercent = $total > 0 ? round(($agentSentiments['Negative'] + $customerSentiments['Negative']) / $total * 100) : 0;
        ?>

        <div class="sentiment-line">
          <!-- Positive -->
          <div class="sentiment-box positive">
            <div class="sentiment-icon"><i class="bi bi-emoji-smile"></i></div>
            <div class="sentiment-value"><?php echo e($positivePercent); ?>%</div>
            <div class="sentiment-label">Positive</div>
          </div>

          <div class="divider"></div>

          <!-- Neutral -->
          <div class="sentiment-box neutral">
            <div class="sentiment-icon"><i class="bi bi-emoji-neutral"></i></div>
            <div class="sentiment-value"><?php echo e($neutralPercent); ?>%</div>
            <div class="sentiment-label">Neutral</div>
          </div>

          <div class="divider"></div>

          <!-- Negative -->
          <div class="sentiment-box negative">
            <div class="sentiment-icon"><i class="bi bi-emoji-frown"></i></div>
            <div class="sentiment-value"><?php echo e($negativePercent); ?>%</div>
            <div class="sentiment-label">Negative</div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4 animate-fade delay-2">
      <div class="compact-speech-card h-100">
        <div class="card-header d-flex justify-content-between align-items-center mb-3">
          <h6 class="card-title mb-0">Speech Rate <small class="text-muted">(Optimal: 100-200 wpm)</small></h6>
          <div class="info-icon" data-bs-toggle="tooltip" title="Words per minute analysis">i</div>
        </div>

        <div class="speech-rate-line">
          <div class="rate-box agent">
            <div class="rate-icon"><i class="bi bi-headset"></i></div>
            <div class="rate-value"><?php echo e(round($data['pace']['agent_pace'] ?? 0)); ?> <span style="font-size: small">(WPM)</span></div>
            <div class="rate-label">Agent</div>
            <div class="rate-comparison">
              <?php echo $data['pace']['agent_pace'] > $data['pace']['customer_pace'] ? 
                  '<i class="bi bi-arrow-up text-warning"></i>' : 
                  ($data['pace']['agent_pace'] < $data['pace']['customer_pace'] ? 
                  '<i class="bi bi-arrow-down text-success"></i>' : 
                  '<i class="bi bi-dash text-muted"></i>'); ?>

            </div>
          </div>

          <div class="divider"></div>

          <div class="rate-box customer">
            <div class="rate-icon"><i class="bi bi-person"></i></div>
            <div class="rate-value"><?php echo e(round($data['pace']['customer_pace'] ?? 0)); ?> <span style="font-size: small">(WPM)</span></div>
            <div class="rate-label">Customer</div>
            <div class="rate-comparison">
              <?php echo $data['pace']['customer_pace'] > $data['pace']['agent_pace'] ? 
                  '<i class="bi bi-arrow-up text-warning"></i>' : 
                  ($data['pace']['customer_pace'] < $data['pace']['agent_pace'] ? 
                  '<i class="bi bi-arrow-down text-primary"></i>' : 
                  '<i class="bi bi-dash text-muted"></i>'); ?>

            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Voice Loudness Card -->
    <div class="col-lg-4 animate-fade delay-3">
      <div class="compact-volume-line">
         <div class="card-header d-flex justify-content-between align-items-center mb-3">
          <h6 class="card-title mb-0">Voice Loudness</h6>
          <div class="info-icon" data-bs-toggle="tooltip" title="Volume distribution during call">i</div>
        </div>
        
        <div class="volume-metrics">
          <!-- Low Volume -->
          <div class="metric-box low">
            <div class="metric-icon">
              <i class="bi bi-volume-down"></i>
            </div>
            <div class="metric-value">
              <?php echo e($data['speaker_loudness']['agent']['lower_loudness_percentage'] ?? 0); ?>%
            </div>
            <div class="metric-label">Low</div>
          </div>
          
          <!-- Optimal Volume -->
          <div class="metric-box optimal">
            <div class="metric-icon">
              <i class="bi bi-check-circle"></i>
            </div>
            <div class="metric-value">
              <?php echo e($data['speaker_loudness']['agent']['optimal_loudness_percentage'] ?? 0); ?>%
            </div>
            <div class="metric-label">Optimal</div>
          </div>
          
          <!-- High Volume -->
          <div class="metric-box high">
            <div class="metric-icon">
              <i class="bi bi-volume-up"></i>
            </div>
            <div class="metric-value">
              <?php echo e($data['speaker_loudness']['agent']['upper_loudness_percentage'] ?? 0); ?>%
            </div>
            <div class="metric-label">High</div>
          </div>
        </div>
      </div>
    </div>


    <!-- Sentiment Timeline Card -->
    <div class="col-lg-6 animate-fade delay-2">
      <div class="professional-card h-100">
        <div class="card-header">
          <span>Sentiment Timeline</span>
          <div class="info-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Detailed timeline of sentiment changes">i</div>
        </div>
        
        <!-- Tabs Navigation -->
        <ul class="nav nav-tabs nav-tabs-card" id="sentimentTabs" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab">All</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="agent-tab" data-bs-toggle="tab" data-bs-target="#agent" type="button" role="tab">Agent</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="customer-tab" data-bs-toggle="tab" data-bs-target="#customer" type="button" role="tab">Customer</button>
          </li>
        </ul>
        
        <!-- Tab Content -->
        <div class="tab-content p-0">
          <!-- All Tab -->
          <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
            <div class="sentiment-table-container" style="max-height: 400px; overflow-y: auto;">
              <table class="sentiment-table">
                <thead style="position: sticky; top: 0; background: white; z-index: 1;">
                  <tr>
                    <th>Speaker</th>
                    <th>Type</th>
                    <th>Duration</th>
                    <th>Intensity</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(isset($data['speakers_transcriptions'])): ?>
                    <?php $__currentLoopData = $data['speakers_transcriptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transcript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>
                          <span class="badge 
                            <?php if(($transcript['speaker'] ?? '') == 'agent'): ?> bg-warning bg-opacity-10 text-warning 
                            <?php elseif(($transcript['speaker'] ?? '') == 'customer'): ?> bg-info bg-opacity-10 text-info
                            <?php else: ?> bg-secondary bg-opacity-10 text-secondary <?php endif; ?> p-1">
                            <?php echo e(ucfirst($transcript['speaker'] ?? 'Unknown')); ?>

                          </span>
                        </td>
                        <td>
                          <span class="badge 
                            <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bg-success bg-opacity-10 text-success
                            <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bg-danger bg-opacity-10 text-danger
                            <?php else: ?> bg-warning bg-opacity-10 text-warning <?php endif; ?> p-1">
                            <i class="bi 
                              <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bi-emoji-smile
                              <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bi-emoji-frown
                              <?php else: ?> bi-dash-circle <?php endif; ?> me-1"></i>
                            <?php echo e($transcript['sentiment'] ?? 'Neutral'); ?>

                          </span>
                        </td>
                        <td>
                          <?php
                            $start = isset($transcript['start_time']) ? strtotime("1970-01-01 " . substr($transcript['start_time'], 0, 5) . " UTC") : 0;
                            $end = isset($transcript['end_time']) ? strtotime("1970-01-01 " . substr($transcript['end_time'], 0, 5) . " UTC") : 0;
                            $duration = $end - $start;
                            echo gmdate("i:s", $duration);
                          ?>
                        </td>
                        <td>
                          <div class="progress" style="height: 4px;">
                            <div class="progress-bar 
                              <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bg-success
                              <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bg-danger
                              <?php else: ?> bg-warning <?php endif; ?>" 
                              role="progressbar" 
                              style="width: <?php echo e(rand(50, 90)); ?>%">
                            </div>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="4" class="text-center text-muted py-4">
                        <i class="bi bi-info-circle me-2"></i>No sentiment data available
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- Agent Tab -->
          <div class="tab-pane fade" id="agent" role="tabpanel" aria-labelledby="agent-tab">
            <div class="sentiment-table-container" style="max-height: 400px; overflow-y: auto;">
              <table class="sentiment-table">
                <thead style="position: sticky; top: 0; background: white; z-index: 1;">
                  <tr>
                    <th>Type</th>
                    <th>Duration</th>
                    <th>Intensity</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(isset($data['speakers_transcriptions'])): ?>
                    <?php $hasAgentData = false; ?>
                    <?php $__currentLoopData = $data['speakers_transcriptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transcript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(($transcript['speaker'] ?? '') == 'agent'): ?>
                        <?php $hasAgentData = true; ?>
                        <tr>
                          <td>
                            <span class="badge 
                              <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bg-success bg-opacity-10 text-success
                              <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bg-danger bg-opacity-10 text-danger
                              <?php else: ?> bg-warning bg-opacity-10 text-warning <?php endif; ?> p-2">
                              <i class="bi 
                                <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bi-emoji-smile
                                <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bi-emoji-frown
                                <?php else: ?> bi-dash-circle <?php endif; ?> me-1"></i>
                              <?php echo e($transcript['sentiment'] ?? 'Neutral'); ?>

                            </span>
                          </td>
                          <td>
                            <?php
                              $start = isset($transcript['start_time']) ? strtotime("1970-01-01 " . substr($transcript['start_time'], 0, 5) . " UTC") : 0;
                              $end = isset($transcript['end_time']) ? strtotime("1970-01-01 " . substr($transcript['end_time'], 0, 5) . " UTC") : 0;
                              $duration = $end - $start;
                              echo gmdate("i:s", $duration);
                            ?>
                          </td>
                          <td>
                            <div class="progress" style="height: 4px;">
                              <div class="progress-bar 
                                <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bg-success
                                <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bg-danger
                                <?php else: ?> bg-warning <?php endif; ?>" 
                                role="progressbar" 
                                style="width: <?php echo e(rand(50, 90)); ?>%">
                              </div>
                            </div>
                          </td>
                        </tr>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$hasAgentData): ?>
                      <tr>
                        <td colspan="3" class="text-center text-muted py-4">
                          <i class="bi bi-info-circle me-2"></i>No agent data available
                        </td>
                      </tr>
                    <?php endif; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="3" class="text-center text-muted py-4">
                        <i class="bi bi-info-circle me-2"></i>No sentiment data available
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- Customer Tab -->
          <div class="tab-pane fade" id="customer" role="tabpanel" aria-labelledby="customer-tab">
            <div class="sentiment-table-container" style="max-height: 400px; overflow-y: auto;">
              <table class="sentiment-table">
                <thead style="position: sticky; top: 0; background: white; z-index: 1;">
                  <tr>
                    <th>Type</th>
                    <th>Duration</th>
                    <th>Intensity</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(isset($data['speakers_transcriptions'])): ?>
                    <?php $hasCustomerData = false; ?>
                    <?php $__currentLoopData = $data['speakers_transcriptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transcript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(($transcript['speaker'] ?? '') == 'customer'): ?>
                        <?php $hasCustomerData = true; ?>
                        <tr>
                          <td>
                            <span class="badge 
                              <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bg-success bg-opacity-10 text-success
                              <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bg-danger bg-opacity-10 text-danger
                              <?php else: ?> bg-warning bg-opacity-10 text-warning <?php endif; ?> p-2">
                              <i class="bi 
                                <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bi-emoji-smile
                                <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bi-emoji-frown
                                <?php else: ?> bi-dash-circle <?php endif; ?> me-1"></i>
                              <?php echo e($transcript['sentiment'] ?? 'Neutral'); ?>

                            </span>
                          </td>
                          <td>
                            <?php
                              $start = isset($transcript['start_time']) ? strtotime("1970-01-01 " . substr($transcript['start_time'], 0, 5) . " UTC") : 0;
                              $end = isset($transcript['end_time']) ? strtotime("1970-01-01 " . substr($transcript['end_time'], 0, 5) . " UTC") : 0;
                              $duration = $end - $start;
                              echo gmdate("i:s", $duration);
                            ?>
                          </td>
                          <td>
                            <div class="progress" style="height: 4px;">
                              <div class="progress-bar 
                                <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bg-success
                                <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bg-danger
                                <?php else: ?> bg-warning <?php endif; ?>" 
                                role="progressbar" 
                                style="width: <?php echo e(rand(50, 90)); ?>%">
                              </div>
                            </div>
                          </td>
                        </tr>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$hasCustomerData): ?>
                      <tr>
                        <td colspan="3" class="text-center text-muted py-4">
                          <i class="bi bi-info-circle me-2"></i>No customer data available
                        </td>
                      </tr>
                    <?php endif; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="3" class="text-center text-muted py-4">
                        <i class="bi bi-info-circle me-2"></i>No sentiment data available
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-6 animate-fade delay-3">
      <div class="time-analysis-card p-3">
        <div class="card-header">
          <span>Timeline Analysis</span>
          <div class="info-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Analysis states">i</div>
        </div>
        <!-- Tab Navigation -->
        <ul class="nav nav-tabs" id="timeAnalysisTabs" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="delays-tab" data-bs-toggle="tab" data-bs-target="#delays" type="button" role="tab">
              <i class="bi bi-clock-history me-1"></i> Delays
              <span class="badge bg-warning bg-opacity-10 text-warning ms-1">
                <?php echo e(isset($data['pause_delay_information']['speaker_delay_duration']) ? 
                  count(array_merge(
                    $data['pause_delay_information']['speaker_delay_duration']['agent'] ?? [],
                    $data['pause_delay_information']['speaker_delay_duration']['customer'] ?? []
                  )) : 0); ?>

              </span>
            </button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link " id="pauses-tab" data-bs-toggle="tab" data-bs-target="#pauses" type="button" role="tab">
              <i class="bi bi-pause-circle me-1"></i> Pauses
              <span class="badge bg-primary bg-opacity-10 text-primary ms-1">
                <?php echo e(isset($data['pause_delay_information']['speaker_pause_duration']) ? 
                  count(array_merge(
                    $data['pause_delay_information']['speaker_pause_duration']['agent'] ?? [],
                    $data['pause_delay_information']['speaker_pause_duration']['customer'] ?? []
                  )) : 0); ?>

              </span>
            </button>
          </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="timeAnalysisTabsContent">
          <div class="tab-pane fade" id="pauses" role="tabpanel">
            <div class="table-container" style="max-height: 400px;">
              <table class="time-analysis-table">
                <thead>
                  <tr>
                    <th width="20%">Speaker</th>
                    <th width="15%">Duration</th>
                    <th width="25%">Time</th>
                    <th width="40%">Context</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(isset($data['pause_delay_information']['speaker_pause_duration'])): ?>
                    <?php
                      $agentPauses = $data['pause_delay_information']['speaker_pause_duration']['agent'] ?? [];
                      $customerPauses = $data['pause_delay_information']['speaker_pause_duration']['customer'] ?? [];
                      $allPauses = array_merge(
                        array_map(function($item) { return $item + ['speaker' => 'Agent']; }, $agentPauses),
                        array_map(function($item) { return $item + ['speaker' => 'Customer']; }, $customerPauses)
                      );
                    ?>

                    <?php $__empty_1 = true; $__currentLoopData = $allPauses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pause): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td>
                          <span class="badge <?php echo e($pause['speaker'] == 'Agent' ? 'bg-warning bg-opacity-10 text-warning  p-2' : 'bg-success bg-opacity-10 text-success'); ?>">
                            <i class="bi <?php echo e($pause['speaker'] == 'Agent' ? 'bi-headset' : 'bi-person'); ?> me-1"></i>
                            <?php echo e($pause['speaker']); ?>

                          </span>
                        </td>
                        <td><?php echo e($pause['pause_duration'] ?? 'N/A'); ?></td>
                        <td><?php echo e($pause['pause_start'] ?? 'N/A'); ?> - <?php echo e($pause['pause_end'] ?? 'N/A'); ?></td>
                        <td class="text-truncate" title="<?php echo e($pause['pause_class'] ?? 'No context'); ?>"><?php echo e($pause['pause_class'] ?? 'No context'); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td colspan="4" class="text-center py-4 text-muted">
                          <i class="bi bi-check-circle me-2"></i> No significant pauses detected
                        </td>
                      </tr>
                    <?php endif; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="4" class="text-center py-4 text-muted">
                        <i class="bi bi-exclamation-triangle me-2"></i> Pause data not available
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Delays Tab -->
          <div class="tab-pane fade  show active" id="delays" role="tabpanel">
            <div class="table-container" style="max-height: 400px;">
              <table class="time-analysis-table">
                <thead>
                  <tr>
                    <th width="20%">Speaker</th>
                    <th width="15%">Duration</th>
                    <th width="25%">Time</th>
                    <th width="40%">Context</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(isset($data['pause_delay_information']['speaker_delay_duration'])): ?>
                    <?php
                      $agentDelays = $data['pause_delay_information']['speaker_delay_duration']['agent'] ?? [];
                      $customerDelays = $data['pause_delay_information']['speaker_delay_duration']['customer'] ?? [];
                      $allDelays = array_merge(
                        array_map(function($item) { return $item + ['speaker' => 'Agent']; }, $agentDelays),
                        array_map(function($item) { return $item + ['speaker' => 'Customer']; }, $customerDelays)
                      );
                    ?>

                    <?php $__empty_1 = true; $__currentLoopData = $allDelays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <?php
                        $context = 'No context available';
                        if(isset($data['speakers_transcriptions'])) {
                          foreach($data['speakers_transcriptions'] as $transcript) {
                            if(isset($transcript['start_time'], $transcript['end_time'], $delay['delay_start'], $delay['delay_end'])) {
                              $start = strtotime("1970-01-01 " . substr($transcript['start_time'], 0, 5) . " UTC");
                              $end = strtotime("1970-01-01 " . substr($transcript['end_time'], 0, 5) . " UTC");
                              $delayStart = strtotime("1970-01-01 " . substr($delay['delay_start'], 0, 5) . " UTC");
                              $delayEnd = strtotime("1970-01-01 " . substr($delay['delay_end'], 0, 5) . " UTC");
                              
                              if($start >= ($delayStart - 5) && $end <= ($delayEnd + 5)) {
                                $context = $transcript['transcript'] ?? 'No context available';
                                break;
                              }
                            }
                          }
                        }
                      ?>
                      <tr>
                        <td>
                          <span class="badge <?php echo e($delay['speaker'] == 'Agent' ? 'bg-warning bg-opacity-10 text-warning' : 'bg-success bg-opacity-10 text-success'); ?>">
                            <i class="bi <?php echo e($delay['speaker'] == 'Agent' ? 'bi-headset' : 'bi-person'); ?> me-1"></i>
                            <?php echo e($delay['speaker']); ?>

                          </span>
                        </td>
                        <td><?php echo e($delay['delay_duration'] ?? 'N/A'); ?></td>
                        <td><?php echo e($delay['delay_start'] ?? 'N/A'); ?> - <?php echo e($delay['delay_end'] ?? 'N/A'); ?></td>
                        <td class="text-truncate" title="<?php echo e($context); ?>"><?php echo e($context); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td colspan="4" class="text-center py-4 text-muted">
                          <i class="bi bi-check-circle me-2"></i> No significant delays detected
                        </td>
                      </tr>
                    <?php endif; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="4" class="text-center py-4 text-muted">
                        <i class="bi bi-exclamation-triangle me-2"></i> Delay data not available
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Right Column - Call Details -->
    <div class="col-lg-6">
      <div class="d-flex flex-column gap-4 h-100">
        <!-- Call Summary -->
        <div class="professional-card animate-fade delay-2">
          <div class="card-header">
            <span>Call Summary</span>
            <div class="info-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Automatically generated call summary">i</div>
          </div>
          <div class="audio-player bg-secondary rounded ">
          <!-- Hidden audio element -->
          <audio id="audioPlayer" src="<?php echo e($data['customer_agent_audio_s3_url'] ?? ''); ?>"></audio>
          
          <div class="audio-controls">
            <button class="audio-btn" title="Skip Backward" onclick="skip(-10)">
              <i class="fas fa-step-backward"></i>
            </button>
            <button class="audio-btn" id="playButton" title="Play" onclick="togglePlay()">
              <i class="fas fa-play" id="playIcon"></i>
            </button>
            <button class="audio-btn" title="Skip Forward" onclick="skip(10)">
              <i class="fas fa-step-forward"></i>
            </button>
          </div>
          
          <div class="audio-progress">
            <div class="audio-progress-filled" id="progressBar"></div>
          </div>
          
          <div class="audio-time">
            <span id="currentTime">0:00</span> / 
            <span id="duration"><?php echo e($data['call_duration']['call_duration'] ?? '0:00'); ?></span>
          </div>
          
          <div class="audio-controls">
            <?php if(isset($data['customer_agent_audio_s3_url'])): ?>
              <a href="<?php echo e($data['customer_agent_audio_s3_url']); ?>" class="audio-btn" title="Download" download>
                <i class="fas fa-download"></i>
              </a>
            <?php endif; ?>
          </div>
          </div>


          <div class="summary-card premium-summary">
            <div class="summary-content">
              <!-- Detailed Summary -->
              <div class="detailed-summary">
                <div class="summary-text arabic-text">
                  <?php echo e($data['transcription_summaries']['detail'] ?? 'No detailed summary available'); ?>

                </div>
              </div>

              <!-- Key Points -->
              <?php if(isset($data['topics']['other']) || isset($data['call_outcome'])): ?>
              <div class="key-points mt-4">
                <div class="section-title">
                  <i class="bi bi-key-fill"></i>
                  <h6>Key Discussion Points</h6>
                </div>
                <div class="points-container">
                  <?php if(isset($data['topics']['main'])): ?>
                    <div class="main-topic">
                      <span class="topic-badge main-badge">
                        Main Topic: &nbsp; <i class="bi bi-bookmark-fill me-1"></i>
                        <?php echo e($data['topics']['main'][0] ?? 'Main Topic'); ?>

                      </span>
                    </div>
                  <?php endif; ?>
                  
                 <div class="compact-key-points">
                    <div class="points-line">
                      Other Topics: &nbsp; 
                      <?php $__currentLoopData = $data['topics']['other'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="point-item">
                          <i class="bi bi-check-circle-fill text-success me-1"></i>
                          <?php echo e($topic); ?>

                        </span>
                        <?php if(!$loop->last): ?>
                          <span class="point-divider">•</span>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                    <?php if(isset($data['call_outcome'])): ?>
                      <div class="outcome-line mt-2">
                       <strong> Call Outcome </strong>:  &nbsp;<i class="fas fa-ticket text-secondary me-1"></i>
                         <?php echo e(implode('، ', $data['call_outcome'])); ?>

                      </div>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Right Column - Call Details -->
    <div class="col-lg-6">
      <div class="d-flex flex-column gap-4 h-100">
        
        <!-- Call Transcription -->
        <div class="professional-card animate-fade delay-3">
          <div class="card-header">
            <span>Full Call Transcription</span>
            <div class="info-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Complete automated call transcription">i</div>
          </div>
          
          <div class="px-4 pt-3 pb-2">
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" id="showTimestamps" checked>
              <label class="form-check-label" for="showTimestamps">Show timestamps</label>
            </div>
          </div>
          
          <div class="transcription-container">
            <?php if(isset($data['speakers_transcriptions'])): ?>
              <?php $__currentLoopData = $data['speakers_transcriptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transcript): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="transcript-line">
                  <span class="timestamp">[<?php echo e($transcript['start_time'] ?? '00:00'); ?>]</span>
                  <span class="speaker <?php echo e($transcript['speaker'] ?? 'agent'); ?>"><?php echo e($transcript['speaker'] ?? 'agent'); ?>:</span>
                  <span class="text"><?php echo e($transcript['transcript'] ?? 'No transcript available'); ?></span>
                  <span class="sentiment-badge badge 
                    <?php if(($transcript['sentiment'] ?? 'Neutral') == 'Positive'): ?> bg-success
                    <?php elseif(($transcript['sentiment'] ?? 'Neutral') == 'Negative'): ?> bg-danger
                    <?php else: ?> bg-warning <?php endif; ?>">
                    <?php echo e($transcript['sentiment'] ?? 'Neutral'); ?>

                  </span>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <div class="text-center text-muted py-4">
                <i class="bi bi-info-circle me-2"></i>No transcription data available
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-12">
       <div class="agent-performance-dashboard">
          <!-- Main Header with Overall Scores -->
          <div class="dashboard-header">
            <div class="agent-profile">
              <div class="avatar">
                <i class="fas fa-headset"></i>
              </div>
              <div class="agent-info">
                <h3>Agent Performance</h3>
                <div class="overall-score">
                  <div class="score-circle" style="--percentage: <?php echo e($data['agent_professionalism']['total_score']['percentage']); ?>%">
                    <span><?php echo e($data['agent_professionalism']['total_score']['percentage']); ?>%</span>
                  </div>
                  <div class="score-details">
                    <div class="score-item">
                      <span class="label">Professionalism</span>
                      <span class="value"><?php echo e($data['agent_professionalism']['total_score']['percentage']); ?>%</span>
                    </div>
                    <div class="score-item">
                      <span class="label">Assessment</span>
                      <span class="value"><?php echo e($data['agent_assessment']['total_score']['percentage']); ?>%</span>
                    </div>
                    <div class="score-item">
                      <span class="label">Cooperation</span>
                      <span class="value"><?php echo e($data['agent_cooperation']['total_score']['percentage']); ?>%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Speech Characteristics -->
            <div class="speech-analysis">
              <h4>Speech Analysis</h4>
              <div class="speech-metrics">
                <div class="metric">
                  <i class="fas fa-volume-up"></i>
                  <span><?php echo e(ucfirst($data['agent_professionalism']['speech_characteristics']['volume']['loudness_class'])); ?> Volume</span>
                  <div class="progress-bar">
                    <div class="progress" style="width: <?php echo e($data['agent_professionalism']['speech_characteristics']['volume']['optimal_loudness_percentage']); ?>%"></div>
                  </div>
                </div>
                <div class="metric">
                  <i class="fas fa-tachometer-alt"></i>
                  <span><?php echo e(round($data['agent_professionalism']['speech_characteristics']['speed'])); ?> WPM</span>
                  <div class="progress-bar">
                    <div class="progress" style="width: 80%"></div> <!-- Adjust based on your ideal speed range -->
                  </div>
                </div>
                <div class="metric">
                  <i class="fas fa-pause"></i>
                  <span><?php echo e($data['agent_professionalism']['speech_characteristics']['pauses']); ?> Pauses</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Tab Navigation -->
          <div class="tabs">
            <button class="tab-btn active" data-tab="professionalism">
              <i class="fas fa-award"></i> Professionalism
            </button>
            <button class="tab-btn" data-tab="assessment">
              <i class="fas fa-clipboard-check"></i> Skills Assessment
            </button>
            <button class="tab-btn" data-tab="cooperation">
              <i class="fas fa-handshake"></i> Cooperation
            </button>
            <button class="tab-btn" data-tab="linguistic">
              <i class="fas fa-language"></i> Linguistic Analysis
            </button>
          </div>

          <!-- Tab Contents -->
          <div class="tab-content">
            <!-- Professionalism Tab -->
            <div class="tab-pane active" id="professionalism">
              <div class="metrics-grid">
                <?php $__currentLoopData = ['customer_satisfaction', 'professionalism', 'tone_consistency', 'polite_language_usage', 'configured_standards_compliance']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="metric-card">
                  <div class="metric-score"><?php echo e($data['agent_professionalism'][$metric]['score']); ?>/10</div>
                  <h4><?php echo e(ucfirst(str_replace('_', ' ', $metric))); ?></h4>
                  <div class="metric-details">
                    <p><strong>Evidence:</strong> "<?php echo e($data['agent_professionalism'][$metric]['evidence']); ?>"</p>
                    <p><strong>Reasoning:</strong> <?php echo e($data['agent_professionalism'][$metric]['reasoning']); ?></p>
                    <p><strong>Determination:</strong> <?php echo e($data['agent_professionalism'][$metric]['determination']); ?></p>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

            <!-- Skills Assessment Tab -->
            <div class="tab-pane" id="assessment">
              <div class="metrics-grid">
                <?php $__currentLoopData = ['communication', 'problem_solving', 'technical_knowledge', 'efficiency']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="metric-card">
                  <div class="metric-score"><?php echo e($data['agent_assessment'][$metric]['score']); ?>/10</div>
                  <h4><?php echo e(ucfirst(str_replace('_', ' ', $metric))); ?></h4>
                  <div class="metric-details">
                    <p><strong>Evidence:</strong> "<?php echo e($data['agent_assessment'][$metric]['evidence']); ?>"</p>
                    <p><strong>Reasoning:</strong> <?php echo e($data['agent_assessment'][$metric]['reasoning']); ?></p>
                    <p><strong>Determination:</strong> <?php echo e($data['agent_assessment'][$metric]['determination']); ?></p>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

            <!-- Cooperation Tab -->
            <div class="tab-pane" id="cooperation">
              <div class="metrics-grid">
                <?php $__currentLoopData = ['agent_proactive_assistance', 'agent_responsiveness', 'agent_empathy', 'effectiveness']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="metric-card">
                  <div class="metric-score"><?php echo e($data['agent_cooperation'][$metric]['score']); ?>/10</div>
                  <h4><?php echo e(ucfirst(str_replace('agent_', '', str_replace('_', ' ', $metric)))); ?></h4>
                  <div class="metric-details">
                    <p><strong>Evidence:</strong> "<?php echo e($data['agent_cooperation'][$metric]['evidence'] ?? 'N/A'); ?>"</p>
                    <p><strong>Reasoning:</strong> <?php echo e($data['agent_cooperation'][$metric]['reasoning']); ?></p>
                    <p><strong>Determination:</strong> <?php echo e($data['agent_cooperation'][$metric]['determination']); ?></p>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

            <!-- Linguistic Analysis Tab -->
            <div class="tab-pane" id="linguistic">
              <div class="full-width-section">
                <h3>Tone Analysis</h3>
                <div class="tone-analysis">
                  <!-- You would loop through tone_analysis data here -->
                  <div class="tone-item">
                    <span class="tone-label">Friendly</span>
                    <div class="progress-bar">
                      <div class="progress" style="width: <?php echo e($data['agent_professionalism']['speech_characteristics']['tone_analysis']['friendly'] ?? 0); ?>%"></div>
                    </div>
                  </div>
                  <!-- Add other tone metrics similarly -->
                </div>
                
                <h3>Language Usage</h3>
                <div class="language-stats">
                  <div class="stat">
                    <span>Formal Language:</span>
                    <span><?php echo e($data['agent_professionalism']['linguistic_analysis']['formal_language_percentage'] ?? 0); ?>%</span>
                  </div>
                  <div class="stat">
                    <span>Polite Phrases:</span>
                    <span><?php echo e($data['agent_professionalism']['polite_language_usage']['score']); ?>/10</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Performance Summary -->
          <div class="performance-summary">
            <div class="summary-header">
              <i class="fas fa-<?php echo e($data['agent_professionalism']['total_score']['percentage'] > 80 ? 'trophy' : 'check-circle'); ?>"></i>
              <h3><?php echo e($data['agent_professionalism']['total_score']['percentage'] > 80 ? 'Excellent Performance' : 'Good Performance'); ?></h3>
            </div>
            <div class="summary-content">
              <p><?php echo e($data['agent_professionalism']['customer_satisfaction']['reasoning']); ?></p>
              <div class="summary-stats">
                <div class="stat">
                  <span>Total Score:</span>
                  <span><?php echo e($data['agent_professionalism']['total_score']['score']); ?>/<?php echo e($data['agent_professionalism']['total_score']['max_score']); ?></span>
                </div>
                <div class="stat">
                  <span>Customer Satisfaction:</span>
                  <span><?php echo e($data['agent_professionalism']['customer_satisfaction']['score']); ?>/10</span>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
        <div class="col-lg-6">
      <div class="word-frequency-card">
        <div class="card-header">
          <h5>Most Frequent Words</h5>
          <div class="info-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Top words used during conversation">i</div>
        </div>

        <div class="word-frequency-container">
          <!-- Agent Words -->
          <div class="speaker-words agent-words">
            <div class="speaker-header">
              <i class="bi bi-headset"></i>
              <span>Agent</span>
            </div>
            <div class="word-cloud">
              <?php $__currentLoopData = array_slice($data['most_common_words']['agent'] ?? [], 0, 15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="word-tag" style="font-size: 0.8rem">
                  <?php echo e($word['word']); ?>

                  <span class="frequency-badge"><?php echo e($word['frequency']); ?></span>
                </span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>

          <!-- Customer Words -->
          <div class="speaker-words customer-words">
            <div class="speaker-header">
              <i class="bi bi-person"></i>
              <span>Customer</span>
            </div>
            <div class="word-cloud">
              <?php $__currentLoopData = array_slice($data['most_common_words']['customer'] ?? [], 0, 15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="word-tag" style="font-size: 0.8rem">
                  <?php echo e($word['word']); ?>

                  <span class="frequency-badge"><?php echo e($word['frequency']); ?></span>
                </span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <small class="text-muted">Showing top 15 words per speaker</small>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const audioPlayer = document.getElementById('audioPlayer');
    const playButton = document.getElementById('playButton');
    const playIcon = document.getElementById('playIcon');
    const progressBar = document.getElementById('progressBar');
    const currentTimeEl = document.getElementById('currentTime');
    const durationEl = document.getElementById('duration');

    // Update time display format
    function formatTime(seconds) {
      const minutes = Math.floor(seconds / 60);
      const secs = Math.floor(seconds % 60);
      return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;
    }

    // Update progress bar
    function updateProgress() {
      const percent = (audioPlayer.currentTime / audioPlayer.duration) * 100;
      progressBar.style.width = `${percent}%`;
      currentTimeEl.textContent = formatTime(audioPlayer.currentTime);
    }

    // Set audio duration when metadata is loaded
    audioPlayer.addEventListener('loadedmetadata', function() {
      durationEl.textContent = formatTime(audioPlayer.duration);
    });

    // Update progress while playing
    audioPlayer.addEventListener('timeupdate', updateProgress);

    // Toggle play/pause
    window.togglePlay = function() {
      if (audioPlayer.paused) {
        audioPlayer.play();
        playIcon.classList.remove('fa-play');
        playIcon.classList.add('fa-pause');
        playButton.title = 'Pause';
      } else {
        audioPlayer.pause();
        playIcon.classList.remove('fa-pause');
        playIcon.classList.add('fa-play');
        playButton.title = 'Play';
      }
    };

    // Skip forward/backward
    window.skip = function(seconds) {
      audioPlayer.currentTime += seconds;
      updateProgress();
    };

    // Click on progress bar to seek
    document.querySelector('.audio-progress').addEventListener('click', function(e) {
      const percent = e.offsetX / this.offsetWidth;
      audioPlayer.currentTime = percent * audioPlayer.duration;
      updateProgress();
    });
  });
</script>

<script>
  // Toggle timestamps visibility
  document.getElementById('showTimestamps').addEventListener('change', function() {
    const timestamps = document.querySelectorAll('.timestamp');
    timestamps.forEach(ts => {
      ts.style.display = this.checked ? 'inline' : 'none';
    });
  });
</script>
<script>
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
  });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\evalia\resources\views/user/task/task_details.blade.php ENDPATH**/ ?>